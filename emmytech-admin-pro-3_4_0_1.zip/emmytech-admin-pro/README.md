# EmmyTech Admin Pro 3.4

A professional, modular WordPress admin/login branding plugin with a fully
customizable, live-updating dashboard, built around one settings object, one
consolidated option, and a clean separation between data, behavior, and views.

## Architecture

```
emmytech-admin-pro.php              Bootstrap: constants, activation hook
includes/
  class-emmytech-admin-pro.php      Thin facade — wires modules together
  class-emmytech-settings.php       Single source of truth: defaults, get/save,
                                     sanitization, migration, export/import/reset
  class-emmytech-login.php          Branded login screen + optional post-login redirect
  class-emmytech-assets.php         CSS/JS enqueueing, admin body classes
  class-emmytech-footer.php         Admin footer text & version branding
  class-emmytech-menu.php           Menu registration, admin bar, menu decluttering
  class-emmytech-admin-pages.php    Page rendering + all form/import/export/reset handling
  class-emmytech-dashboard.php      Dashboard widgets + filterable stat/quick-action/
                                     activity-type catalogs + login tracking
uninstall.php                       WP_UNINSTALL_PLUGIN-guarded cleanup, multisite-aware
assets/css/  assets/js/             Styles & scripts (dashboard-glance.css/.js = the full-width
                                     dashboard layout; activity-timer.js = the live clock and
                                     live-updating "time ago" feed timestamps; both loaded on
                                     the Dashboard screen only)
assets/js/vendor/                   Bundled third-party JS (Chart.js, MIT license) — no CDN calls
```

Each class takes only the collaborators it needs through its constructor
(dependency injection), so any module can be read, tested, or replaced on
its own.

## What's new in 3.4 — Activity Feed, live timers, and a deeper Server Information widget

- **Activity Feed widget** — a single, merged, chronological timeline of
  recent posts, comments, new user registrations, and user logins. Choose
  which event types appear and in what priority order, and how many items
  to show, under **EmmyTech → Dashboard**. Each entry links straight to the
  post editor, the comment, or the user's profile.
- **"User activities."** WordPress does not track logins on its own, so a
  prefixed user meta value (`_emmytech_pro_last_login`) is recorded on the
  documented `wp_login` hook — no session data, no IP address, just a
  timestamp — which is what powers the "so-and-so logged in" entries. It is
  removed for every user on uninstall.
- **Live timers.** Every Activity Feed timestamp ticks forward on its own —
  "5 minutes ago" becomes "6 minutes ago" — recomputed client-side every 30
  seconds, no page reload and no repeated server requests. The Server
  Information widget gained a **live, ticking server clock** for the same
  reason: a dashboard should feel alive, not like a snapshot from whenever
  it was loaded.
- **Server Information widget** (renamed from System Info) now also shows
  the database version (via `$wpdb->db_version()`, not a raw query), server
  software, PHP extensions in use, max execution time, site timezone, and
  debug-mode status — everything you'd want on hand before contacting
  support, with the live clock optional and independently toggleable.
- **Fully customizable, same pattern as Stats/Quick Actions.** The
  drag-to-reorder checklist used for Site Statistics and Quick Actions is
  now shared by a third settings group, Activity Feed event types, instead
  of three copies of similar code (`emmytech_pro_activity_feed_types`
  filter for third-party event types, same shape as the other two catalogs).
- **A more seamless interface.** A CSS pass unifies widget chrome across
  every layout: title bars blend into their body instead of a hard seam,
  cards lift subtly on hover, interactive elements share one consistent
  focus outline, and transitions are used consistently rather than ad hoc.

## What's new in 3.3 — the EmmyTech widgets *are* the Dashboard

Until now the EmmyTech widgets were dropped into WordPress's normal dashboard
column: one narrow strip of boxes with the rest of the screen empty, mixed in
with WordPress's own widgets. 3.3 turns the Dashboard into a single,
full-width, at-a-glance screen.

- **"At a glance" layout (new default).** All widgets share one responsive
  grid: welcome banner; Today's Highlights beside Site Statistics; the three
  charts side by side; Top Content beside Upcoming Schedule; Quick Actions
  beside System Info. It is built purely with CSS (flex + `order`), so it
  reflows from wide desktops down to phones.
- **No holes.** Widgets grow to fill their row, so switching a widget off —
  here or per-user in Screen Options — never leaves a gap.
- **Compact stat cards** (icon left, figures right) and **tile-style Quick
  Actions**, so far more fits on one screen.
- **WordPress's own widgets and welcome panel are hidden** (At a Glance,
  Activity, Site Health, Quick Draft, Events and News) while "Hide the default
  WordPress widgets" is on. PHP/browser upgrade warnings are deliberately kept
  and pinned to the top. Third-party plugins' widgets still appear, after the
  EmmyTech ones.
- **Fixed positions.** In this layout drag-to-reorder is off (widgets have a
  designed place). Collapse and Screen Options show/hide still work.
- **Classic layout still available:** *EmmyTech → Dashboard → Dashboard
  Layout* switches back to WordPress's native draggable columns at any time.
- Users who can't see the EmmyTech widgets (below *Contributor* level) keep
  WordPress's normal dashboard rather than an empty one.
- **Fixed:** the *Content Mix* and *Content Growth* charts did not draw in
  3.2.0 (the doughnut's centre-label plugin threw an error, which also stopped
  the charts after it). Each chart is now isolated so one failure can't block
  the others, and chart colours adapt to the card background.

## What's new in 3.2 — chart-driven dashboard, redesigned to a dark analytics look

Restyled around a dark, card-based analytics aesthetic (colored icon badges,
trend indicators, real charts) instead of hijacking the wp-admin sidebar
itself — see "A note on scope" below for why.

- **Today's Highlights** — 4 colored icon cards (Posts, Comments, Media,
  New Users) each showing today's count and a trend vs. yesterday, real
  data via `WP_Query` / `WP_Comment_Query` / `WP_User_Query` date ranges.
- **Weekly Publishing Activity** — bar chart of posts published per day
  over the last 7 days.
- **Content Mix** — donut chart of posts/pages/media with the posts
  percentage shown in the center, matching the "82.3%" style center-label
  donut common in analytics dashboards.
- **Content Growth** — line/area chart of posts published per month over
  the last 12 months.
- **Top Content** — table of the 5 most-commented published posts, each
  with a progress bar and a comment-count badge.
- **Upcoming Schedule** — color-coded list of the next scheduled
  posts/pages, gated behind `edit_others_posts` so contributors can't see
  other authors' unpublished schedule.
- Charts are drawn with a **locally bundled Chart.js 4.5.1** (MIT
  licensed, vendored under `assets/js/vendor/`) — no CDN, no external
  requests, works offline.
- The two heavier chart queries (weekly activity, content growth) are
  cached in transients and automatically invalidated on `save_post` /
  `deleted_post` / `trashed_post` / `untrashed_post`.
- Every new widget is independently toggleable from **EmmyTech →
  Dashboard**, same as before.

### A note on scope

The reference design this was modeled on replaces the entire wp-admin
chrome — its own sidebar navigation, its own top bar. This plugin
deliberately does not do that: replacing wp-admin's navigation would
fight (and likely break) Screen Options, other plugins' menu items, admin
notices, and accessibility behavior that core and every other plugin
depend on. Instead, the dark card/chart aesthetic and the underlying real
WordPress data are brought into the **existing EmmyTech dashboard
widgets** on the native WordPress Dashboard screen, which is the
supported extension point for exactly this kind of customization.

## What's new in 3.1 — a genuinely customizable dashboard

- **Four independent dashboard widgets** (Welcome, Site Statistics, Quick
  Actions, System Info) instead of one fixed box. Because each is a normal
  `wp_add_dashboard_widget()` box, WordPress core already gives every user
  native drag-to-reorder, collapse, and per-user show/hide via the
  Dashboard's own **Screen Options** tab — no custom code needed for that.
- **Choose & reorder stat cards.** Under **EmmyTech → Dashboard**, pick
  which of 8 stat cards appear (published/draft posts, published pages,
  approved/pending comments, media count, total users, active plugins) and
  drag them into the order you want, with a jQuery-UI-powered checklist.
- **Choose & reorder quick actions** the same way (New Post, New Page,
  Media, Users, Plugins, Comments, EmmyTech Settings, My Profile) — each
  link only ever shown to users who actually have the matching capability.
- **Developer-extensible.** Three filters let other plugins or a theme add
  their own entries without touching this plugin's code:
  `emmytech_pro_dashboard_stats`, `emmytech_pro_quick_actions`, and
  `emmytech_pro_activity_feed_types`. See the **EmmyTech → About** page for
  copy-paste examples.
- **Activity Feed widget** — a merged, live-updating timeline of recent
  posts, comments, user registrations, and logins, customizable the same
  way as Stats and Quick Actions (choose types, order, and item count).
- **Server Information widget** — WordPress/PHP/database versions, server
  software, active theme, HTTPS status, PHP extensions, memory limit, max
  execution time, max upload size, timezone, debug-mode status, and an
  optional live, ticking server clock — everything for fast support
  requests, updating on its own.

## Full feature list

- **Branded login screen** — dark gradient background, rounded card,
  configurable accent color and background color, responsive down to
  small screens.
- **Optional custom logo URL** with a configurable logo width; falls back
  to a clean text mark when no logo is set.
- **Dark admin navigation**, toggleable, with a light-mode accent
  highlight used automatically when it's off.
- **EmmyTech Control Center menu** with a configurable Dashicon.
- **Admin Appearance page** with a live preview (WordPress core color
  picker + instant dark/light toggle).
- **Fully customizable dashboard** (see above), in a full-width "at a
  glance" layout or WordPress's classic draggable columns.
- **Activity Feed with live timers** and a **Server Information widget**
  with a live clock (see above).
- **Admin-bar branding** with a dropdown to Appearance, Dashboard
  Settings, and New Post; can be turned off entirely.
- **Custom footer** — editable text (basic HTML allowed) and a toggle to
  replace the WordPress version number with the plugin's own version.
- **Admin menu decluttering** — hide any top-level menu slug (Comments,
  Tools, custom post types, etc.) admin-wide. The Dashboard and the
  EmmyTech menu itself can never be hidden, so this can't lock anyone out.
- **Post-login redirect** — send non-admin users to a custom URL after
  login, with an explicit opt-in to also apply it to administrators.
  Never overrides a link that was already headed somewhere specific.
- **Settings export/import** — download your configuration as JSON and
  restore it on another site (or as a backup); imported files are
  re-validated field-by-field, never trusted as-is.
- **One-click reset to defaults**, with a confirmation prompt.
- **Responsive, seamless admin UI** — unified widget chrome, hover and
  focus states, consistent transitions — across the login screen,
  dashboard widgets, and every settings page.
- **WordPress-core-safe hooks only** — `login_enqueue_scripts`,
  `login_redirect`, `wp_login`, `admin_menu`, `admin_enqueue_scripts`,
  `wp_dashboard_setup`, `admin_bar_menu`, `admin_footer_text`,
  `update_footer`, `admin_post_*`, `plugin_action_links`. No core files
  edited, no core classes overridden, no direct database queries.
- **Settings stored in one WordPress option** (`emmytech_pro_settings`),
  with automatic migration from the 2.x, 3.0, and 3.3 option shapes.
- **Uninstall cleanup** via `uninstall.php` (the pattern recommended by
  the WordPress Plugin Handbook), looping every site on a multisite
  network, removing legacy option names, cached transients, and the
  per-user last-login meta.

## Third-party libraries

- **Chart.js 4.5.1** (MIT license) — bundled under
  `assets/js/vendor/chart.umd.min.js` with its license file alongside it.
  Only loaded on the WordPress Dashboard screen, only when at least one
  chart widget is enabled.

## Privacy note: login tracking

The Activity Feed's "user logins" entries require WordPress to know when a
user last logged in, which core does not track. A single timestamp is
stored per user under the `_emmytech_pro_last_login` user meta key,
recorded on the documented `wp_login` action — no IP address, no session
identifiers, no browser data. It is only ever read by users with the
`list_users` capability (the same gate as the Users admin screen), and it
is removed for every user, network-wide, on uninstall.

## Security & code-quality notes

- Every settings write is capability-checked (filterable via
  `emmytech_pro_capability`, `manage_options` by default) and
  nonce-verified (`check_admin_referer` / `wp_nonce_field`, plus dedicated
  nonces for export, import, and reset).
- Every value written to the database is sanitized with the matching
  WordPress function (`esc_url_raw`, `sanitize_hex_color`, `absint`,
  `wp_kses_post`, `sanitize_text_field`, `sanitize_key`), including
  imported JSON, which is treated as untrusted input and re-validated
  through the same sanitizers as the settings forms.
- Every value echoed to the page is escaped (`esc_html`, `esc_attr`,
  `esc_url`, `esc_textarea`).
- The Activity Feed and Upcoming Schedule widgets gate each event type or
  entire widget behind the WordPress capability that matches its content
  (`edit_posts`, `moderate_comments`, `list_users`, `edit_others_posts`),
  so a Contributor never sees another author's unpublished schedule or
  another user's registration/login activity.
- Verified with `php -l` on every file and a from-scratch WordPress-stub
  smoke test exercising activation, every page render, every dashboard
  widget (including chart payload shape/types and the Activity Feed's
  merged, capability-filtered, newest-first ordering), transient caching
  and invalidation (charts and the activity feed, including invalidation
  on login), the login-tracking meta write, the settings save handler
  (including the unchecked-checkbox case and the generalized sortable
  save loop shared by Stats/Quick Actions/Activity Feed types),
  export → import round-tripping, reset-to-defaults, the menu-hiding
  safeguard, the login-redirect logic, admin-bar toggling, and the
  developer filters.

## Installation

Deactivate/delete any older EmmyTech Admin Customization plugin first if
active, then install this ZIP through **Plugins → Add New → Upload
Plugin**. Do not run two EmmyTech admin-branding plugins together — both
modify the same wp-admin and login surfaces.

## Configuration

**EmmyTech → Control Center** — logo, accent/login colors, dark
navigation, admin-bar branding, footer text.

**EmmyTech → Appearance** — menu icon, live-previewed accent color and
navigation mode.

**EmmyTech → Dashboard** — the dashboard layout (At a glance / Classic),
which widgets appear, the cards/links/event types and order inside the
Stats, Quick Actions, and Activity Feed widgets, how many activity items
to show, and whether the Server Information widget shows its live clock.

**EmmyTech → Tools** — hide admin menu items, set a post-login redirect,
export/import settings, reset to defaults.

**EmmyTech → About** — version, changelog, and copy-paste filter examples
for developers.

## Upgrading

Upgrades from 2.x, 3.0, and 3.3 are all handled automatically the first
time the plugin loads — old option shapes are migrated into the current
consolidated format and the legacy rows are removed. No action required.
