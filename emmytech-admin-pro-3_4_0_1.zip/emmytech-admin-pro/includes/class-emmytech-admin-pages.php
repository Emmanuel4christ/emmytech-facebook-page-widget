<?php
/**
 * Admin pages module for EmmyTech Admin Pro.
 *
 * Handles both rendering (the five EmmyTech submenu screens) and the
 * request handling behind them: the shared settings-save handler, plus
 * dedicated admin-post actions for export, import, and reset — each
 * capability-checked and nonce-verified independently.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EmmyTech_Admin_Pages {

	const NONCE_ACTION = 'emmytech_save_settings';
	const NONCE_FIELD  = 'emmytech_nonce';

	/** @var EmmyTech_Settings */
	private $settings;

	public function __construct( EmmyTech_Settings $settings ) {
		$this->settings = $settings;

		add_action( 'admin_init', array( $this, 'maybe_save_settings' ) );
		add_action( 'admin_post_emmytech_export_settings', array( $this, 'handle_export' ) );
		add_action( 'admin_post_emmytech_import_settings', array( $this, 'handle_import' ) );
		add_action( 'admin_post_emmytech_reset_settings', array( $this, 'handle_reset' ) );
	}

	/* ================================================================
	 * Shared save handler for the Control Center, Appearance, and
	 * Dashboard Settings forms. Each form only submits the fields that
	 * belong to it; anything not present in $_POST keeps its current
	 * saved value.
	 * ============================================================== */

	public function maybe_save_settings() {
		if ( empty( $_POST['emmytech_save'] ) ) {
			return;
		}
		if ( ! current_user_can( EmmyTech_Settings::capability() ) ) {
			return;
		}
		check_admin_referer( self::NONCE_ACTION, self::NONCE_FIELD );

		$current = $this->settings->all();
		$updated = array();

		if ( isset( $_POST['logo_url'] ) ) {
			$updated['logo_url'] = esc_url_raw( wp_unslash( $_POST['logo_url'] ) );
		}
		if ( isset( $_POST['logo_width'] ) ) {
			$updated['logo_width'] = EmmyTech_Settings::sanitize_int_range( wp_unslash( $_POST['logo_width'] ), 40, 600, $current['logo_width'] );
		}
		if ( isset( $_POST['accent_color'] ) ) {
			$updated['accent_color'] = EmmyTech_Settings::sanitize_hex( wp_unslash( $_POST['accent_color'] ), $current['accent_color'] );
		}
		if ( isset( $_POST['login_bg_color'] ) ) {
			$updated['login_bg_color'] = EmmyTech_Settings::sanitize_hex( wp_unslash( $_POST['login_bg_color'] ), $current['login_bg_color'] );
		}
		if ( isset( $_POST['menu_icon'] ) ) {
			$icon                  = sanitize_text_field( wp_unslash( $_POST['menu_icon'] ) );
			$updated['menu_icon']  = '' !== $icon ? $icon : 'dashicons-admin-customizer';
		}
		if ( isset( $_POST['custom_footer_text'] ) ) {
			$updated['custom_footer_text'] = wp_kses_post( wp_unslash( $_POST['custom_footer_text'] ) );
		}
		if ( isset( $_POST['login_redirect_url'] ) ) {
			$updated['login_redirect_url'] = esc_url_raw( wp_unslash( $_POST['login_redirect_url'] ) );
		}
		if ( isset( $_POST['dashboard_layout'] ) ) {
			$updated['dashboard_layout'] = EmmyTech_Settings::sanitize_layout( wp_unslash( $_POST['dashboard_layout'] ), $current['dashboard_layout'] );
		}
		if ( isset( $_POST['hidden_menu_slugs'] ) ) {
			$updated['hidden_menu_slugs'] = EmmyTech_Settings::sanitize_slug_list( wp_unslash( $_POST['hidden_menu_slugs'] ) );
		}
		if ( isset( $_POST['activity_feed_limit'] ) ) {
			$updated['activity_feed_limit'] = EmmyTech_Settings::sanitize_int_range( wp_unslash( $_POST['activity_feed_limit'] ), 3, 20, $current['activity_feed_limit'] );
		}

		// Checkbox-backed booleans: only present in $_POST for the form
		// that owns them, but we still want an explicit "off" when a
		// checkbox is unchecked, which is why each of these pages carries
		// hidden mirror fields for the booleans it doesn't render. We
		// detect "this form's booleans" via a marker field per page.
		$boolean_fields = array(
			'dark_admin_nav', 'admin_bar_branding', 'hide_footer_version',
			'dashboard_widget_hero', 'dashboard_widget_highlights', 'dashboard_widget_stats',
			'dashboard_widget_weekly_activity', 'dashboard_widget_content_mix', 'dashboard_widget_content_growth',
			'dashboard_widget_top_content', 'dashboard_widget_schedule', 'dashboard_widget_activity',
			'dashboard_widget_quick_actions', 'dashboard_widget_system_info', 'replace_dashboard', 'login_redirect_admins',
			'server_info_show_clock',
		);
		foreach ( $boolean_fields as $field ) {
			if ( isset( $_POST[ 'emmytech_field_' . $field ] ) ) {
				$updated[ $field ] = ! empty( $_POST[ $field ] ) ? '1' : '0';
			}
		}

		// Drag-to-reorder checklists (Stats, Quick Actions, Activity Feed
		// event types) all submit the same shape — a comma-joined "order"
		// field plus a checkbox array of enabled keys — so one loop
		// handles every group instead of repeating the same four lines.
		$sortable_groups = array(
			'dashboard_stats'     => array( EmmyTech_Dashboard::class, 'stat_catalog' ),
			'quick_actions'       => array( EmmyTech_Dashboard::class, 'quick_action_catalog' ),
			'activity_feed_types' => array( EmmyTech_Dashboard::class, 'activity_type_catalog' ),
		);
		foreach ( $sortable_groups as $setting_key => $catalog_callback ) {
			if ( ! isset( $_POST[ $setting_key . '_order' ] ) ) {
				continue;
			}
			$order           = explode( ',', sanitize_text_field( wp_unslash( $_POST[ $setting_key . '_order' ] ) ) );
			$enabled_raw     = isset( $_POST[ $setting_key . '_enabled' ] ) ? (array) wp_unslash( $_POST[ $setting_key . '_enabled' ] ) : array();
			$enabled         = self::sanitize_key_array( $enabled_raw );
			$ordered_enabled = array_values( array_intersect( $order, $enabled ) );
			$updated[ $setting_key ] = EmmyTech_Settings::sanitize_key_list( $ordered_enabled, array_keys( call_user_func( $catalog_callback ) ) );
		}

		$this->settings->save( $updated );

		add_action( 'admin_notices', array( $this, 'render_saved_notice' ) );
	}

	/**
	 * Safely reduces a raw $_POST array (which may contain unexpected
	 * nested arrays from a malformed request) down to a flat list of
	 * sanitized keys.
	 *
	 * @param array $raw
	 * @return array
	 */
	private static function sanitize_key_array( array $raw ) {
		$clean = array();
		foreach ( $raw as $item ) {
			if ( is_scalar( $item ) ) {
				$clean[] = sanitize_key( $item );
			}
		}
		return $clean;
	}

	public function render_saved_notice() {
		echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'EmmyTech settings saved.', 'emmytech-admin-pro' ) . '</p></div>';
	}

	/* ================================================================
	 * Export / Import / Reset (admin-post handlers)
	 * ============================================================== */

	public function handle_export() {
		if ( ! current_user_can( EmmyTech_Settings::capability() ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to do this.', 'emmytech-admin-pro' ) );
		}
		check_admin_referer( 'emmytech_export_settings' );

		$json     = $this->settings->export_json();
		$filename = 'emmytech-admin-pro-settings-' . gmdate( 'Y-m-d' ) . '.json';

		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Content-Length: ' . strlen( $json ) );
		echo $json; // phpcs:ignore -- pre-encoded JSON, not HTML output.
		exit;
	}

	public function handle_import() {
		if ( ! current_user_can( EmmyTech_Settings::capability() ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to do this.', 'emmytech-admin-pro' ) );
		}
		check_admin_referer( 'emmytech_import_settings' );

		$redirect = admin_url( 'admin.php?page=emmytech-tools' );

		if ( empty( $_FILES['emmytech_import_file']['tmp_name'] ) || UPLOAD_ERR_OK !== $_FILES['emmytech_import_file']['error'] ) {
			wp_safe_redirect( add_query_arg( 'emmytech_import', 'error', $redirect ) );
			exit;
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_file_get_contents -- small local temp upload, WP_Filesystem is not warranted here.
		$contents = file_get_contents( $_FILES['emmytech_import_file']['tmp_name'] );
		$result   = $this->settings->import_json( $contents );

		$redirect = add_query_arg( 'emmytech_import', is_wp_error( $result ) ? 'error' : 'success', $redirect );
		wp_safe_redirect( $redirect );
		exit;
	}

	public function handle_reset() {
		if ( ! current_user_can( EmmyTech_Settings::capability() ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to do this.', 'emmytech-admin-pro' ) );
		}
		check_admin_referer( 'emmytech_reset_settings' );

		$this->settings->reset_to_defaults();

		wp_safe_redirect( add_query_arg( 'emmytech_reset', 'success', admin_url( 'admin.php?page=emmytech-tools' ) ) );
		exit;
	}

	/* ================================================================
	 * Page: Control Center
	 * ============================================================== */

	public function render_control_center_page() {
		$this->guard();
		$s = $this->settings->all();
		?>
		<div class="wrap emmytech-settings">
			<h1><?php esc_html_e( 'EmmyTech Control Center', 'emmytech-admin-pro' ); ?></h1>
			<p class="emmytech-intro"><?php esc_html_e( 'Configure your branded WordPress administration experience.', 'emmytech-admin-pro' ); ?></p>

			<?php $this->render_submenu_nav( 'emmytech-control-center' ); ?>

			<form method="post">
				<?php $this->nonce_field(); ?>

				<div class="emmytech-setting-card">
					<h2><?php esc_html_e( 'Branding', 'emmytech-admin-pro' ); ?></h2>

					<label for="logo_url"><?php esc_html_e( 'Logo URL', 'emmytech-admin-pro' ); ?></label>
					<input class="regular-text" type="url" id="logo_url" name="logo_url" value="<?php echo esc_attr( $s['logo_url'] ); ?>" placeholder="https://example.com/logo.png">
					<p class="description"><?php esc_html_e( 'Paste your full logo URL. Leave empty to use the site name as a text mark.', 'emmytech-admin-pro' ); ?></p>

					<label for="logo_width"><?php esc_html_e( 'Login Logo Width (px)', 'emmytech-admin-pro' ); ?></label>
					<input type="number" id="logo_width" name="logo_width" min="40" max="600" value="<?php echo esc_attr( $s['logo_width'] ); ?>">

					<label for="accent_color"><?php esc_html_e( 'Accent Color', 'emmytech-admin-pro' ); ?></label>
					<input type="color" id="accent_color" name="accent_color" value="<?php echo esc_attr( $s['accent_color'] ); ?>">

					<label for="login_bg_color"><?php esc_html_e( 'Login Background Color', 'emmytech-admin-pro' ); ?></label>
					<input type="color" id="login_bg_color" name="login_bg_color" value="<?php echo esc_attr( $s['login_bg_color'] ); ?>">
				</div>

				<div class="emmytech-setting-card">
					<h2><?php esc_html_e( 'Interface', 'emmytech-admin-pro' ); ?></h2>

					<?php $this->checkbox_field( 'dark_admin_nav', $s['dark_admin_nav'], __( 'Use dark admin navigation', 'emmytech-admin-pro' ) ); ?>
					<?php $this->checkbox_field( 'admin_bar_branding', $s['admin_bar_branding'], __( 'Show EmmyTech branding in the admin bar', 'emmytech-admin-pro' ) ); ?>
				</div>

				<div class="emmytech-setting-card">
					<h2><?php esc_html_e( 'Footer', 'emmytech-admin-pro' ); ?></h2>

					<label for="custom_footer_text"><?php esc_html_e( 'Custom Footer Text', 'emmytech-admin-pro' ); ?></label>
					<textarea class="large-text" id="custom_footer_text" name="custom_footer_text" rows="2"><?php echo esc_textarea( $s['custom_footer_text'] ); ?></textarea>
					<p class="description"><?php esc_html_e( 'Basic HTML like <strong> is allowed.', 'emmytech-admin-pro' ); ?></p>

					<?php $this->checkbox_field( 'hide_footer_version', $s['hide_footer_version'], __( 'Hide the WordPress version number in the admin footer', 'emmytech-admin-pro' ) ); ?>
				</div>

				<?php $this->submit_button(); ?>
			</form>
		</div>
		<?php
	}

	/* ================================================================
	 * Page: Appearance (live preview)
	 * ============================================================== */

	public function render_appearance_page() {
		$this->guard();
		$s = $this->settings->all();
		?>
		<div class="wrap emmytech-settings">
			<h1><?php esc_html_e( 'Admin Appearance', 'emmytech-admin-pro' ); ?></h1>
			<p class="emmytech-intro"><?php esc_html_e( 'Fine-tune the look of wp-admin with a live preview before you save.', 'emmytech-admin-pro' ); ?></p>

			<?php $this->render_submenu_nav( 'emmytech-admin-appearance' ); ?>

			<form method="post">
				<?php $this->nonce_field(); ?>

				<div class="emmytech-setting-card">
					<h2><?php esc_html_e( 'Live Preview', 'emmytech-admin-pro' ); ?></h2>

					<label for="menu_icon"><?php esc_html_e( 'Menu Icon (Dashicon slug)', 'emmytech-admin-pro' ); ?></label>
					<input class="regular-text" type="text" id="menu_icon" name="menu_icon" value="<?php echo esc_attr( $s['menu_icon'] ); ?>" placeholder="dashicons-admin-customizer">
					<p class="description">
						<?php
						printf(
							/* translators: %s: link to the Dashicons reference. */
							esc_html__( 'Browse available icon names at %s', 'emmytech-admin-pro' ),
							'<a href="https://developer.wordpress.org/resource/dashicons/" target="_blank" rel="noopener noreferrer">developer.wordpress.org/resource/dashicons</a>'
						);
						?>
					</p>

					<label for="accent_color_live"><?php esc_html_e( 'Accent Color', 'emmytech-admin-pro' ); ?></label>
					<input type="text" id="accent_color_live" name="accent_color" class="emmytech-color-field" value="<?php echo esc_attr( $s['accent_color'] ); ?>">

					<?php $this->checkbox_field( 'dark_admin_nav', $s['dark_admin_nav'], __( 'Use dark admin navigation', 'emmytech-admin-pro' ), 'dark_admin_nav_live' ); ?>

					<div id="emmytech-live-preview" class="emmytech-preview <?php echo '1' === $s['dark_admin_nav'] ? 'is-dark' : 'is-light'; ?>" style="--preview-accent:<?php echo esc_attr( $s['accent_color'] ); ?>">
						<div class="emmytech-preview-menu">
							<span class="emmytech-preview-menu-item is-active">Dashboard</span>
							<span class="emmytech-preview-menu-item">Posts</span>
							<span class="emmytech-preview-menu-item">EmmyTech</span>
						</div>
						<div class="emmytech-preview-content">
							<div class="emmytech-preview-button">Primary Action</div>
						</div>
					</div>
				</div>

				<?php $this->submit_button( __( 'Save Appearance', 'emmytech-admin-pro' ) ); ?>
			</form>
		</div>
		<?php
	}

	/* ================================================================
	 * Page: Dashboard Settings (customization centerpiece)
	 * ============================================================== */

	public function render_dashboard_page() {
		$this->guard();
		$s                = $this->settings->all();
		$stat_catalog     = EmmyTech_Dashboard::stat_catalog();
		$action_catalog   = EmmyTech_Dashboard::quick_action_catalog();
		$activity_catalog = EmmyTech_Dashboard::activity_type_catalog();
		?>
		<div class="wrap emmytech-settings">
			<h1><?php esc_html_e( 'Dashboard Settings', 'emmytech-admin-pro' ); ?></h1>
			<p class="emmytech-intro"><?php esc_html_e( 'Choose which EmmyTech widgets appear on the Dashboard, and customize what each one shows. Drag items to reorder them.', 'emmytech-admin-pro' ); ?></p>

			<?php $this->render_submenu_nav( 'emmytech-dashboard-settings' ); ?>

			<form method="post">
				<?php $this->nonce_field(); ?>

				<div class="emmytech-setting-card">
					<h2><?php esc_html_e( 'Dashboard Layout', 'emmytech-admin-pro' ); ?></h2>
					<fieldset>
						<label class="emmytech-radio">
							<input type="radio" name="dashboard_layout" value="glance" <?php checked( $s['dashboard_layout'], 'glance' ); ?>>
							<strong><?php esc_html_e( 'At a glance (recommended)', 'emmytech-admin-pro' ); ?></strong>
							<span class="description"><?php esc_html_e( 'Every widget on one full-width, responsive grid: welcome banner, today\'s numbers and site statistics up top, the three charts side by side, then top content, schedule, activity feed, quick actions and server information. Widgets have a fixed place, so there is nothing to arrange.', 'emmytech-admin-pro' ); ?></span>
						</label>
						<label class="emmytech-radio">
							<input type="radio" name="dashboard_layout" value="classic" <?php checked( $s['dashboard_layout'], 'classic' ); ?>>
							<strong><?php esc_html_e( 'Classic WordPress columns', 'emmytech-admin-pro' ); ?></strong>
							<span class="description"><?php esc_html_e( 'WordPress\'s native dashboard layout, where each user can drag widgets between columns and choose 1 to 4 columns in Screen Options.', 'emmytech-admin-pro' ); ?></span>
						</label>
					</fieldset>
				</div>

				<div class="emmytech-setting-card">
					<h2><?php esc_html_e( 'Widgets', 'emmytech-admin-pro' ); ?></h2>
					<p class="description"><?php esc_html_e( 'Each widget can also be shown or hidden per user from the Dashboard\'s own Screen Options tab.', 'emmytech-admin-pro' ); ?></p>

					<?php $this->checkbox_field( 'dashboard_widget_hero', $s['dashboard_widget_hero'], __( 'Welcome widget', 'emmytech-admin-pro' ) ); ?>
					<?php $this->checkbox_field( 'dashboard_widget_highlights', $s['dashboard_widget_highlights'], __( "Today's Highlights widget (posts/comments/media/users vs. yesterday)", 'emmytech-admin-pro' ) ); ?>
					<?php $this->checkbox_field( 'dashboard_widget_stats', $s['dashboard_widget_stats'], __( 'Site Statistics widget', 'emmytech-admin-pro' ) ); ?>
					<?php $this->checkbox_field( 'dashboard_widget_weekly_activity', $s['dashboard_widget_weekly_activity'], __( 'Weekly Publishing Activity chart', 'emmytech-admin-pro' ) ); ?>
					<?php $this->checkbox_field( 'dashboard_widget_content_mix', $s['dashboard_widget_content_mix'], __( 'Content Mix chart (posts / pages / media)', 'emmytech-admin-pro' ) ); ?>
					<?php $this->checkbox_field( 'dashboard_widget_content_growth', $s['dashboard_widget_content_growth'], __( 'Content Growth chart (last 12 months)', 'emmytech-admin-pro' ) ); ?>
					<?php $this->checkbox_field( 'dashboard_widget_top_content', $s['dashboard_widget_top_content'], __( 'Top Content widget (most-commented posts)', 'emmytech-admin-pro' ) ); ?>
					<?php $this->checkbox_field( 'dashboard_widget_schedule', $s['dashboard_widget_schedule'], __( 'Upcoming Schedule widget', 'emmytech-admin-pro' ) ); ?>
					<?php $this->checkbox_field( 'dashboard_widget_activity', $s['dashboard_widget_activity'], __( 'Activity Feed widget (recent posts, comments, and user activity, live-updating)', 'emmytech-admin-pro' ) ); ?>
					<?php $this->checkbox_field( 'dashboard_widget_quick_actions', $s['dashboard_widget_quick_actions'], __( 'Quick Actions widget', 'emmytech-admin-pro' ) ); ?>
					<?php $this->checkbox_field( 'dashboard_widget_system_info', $s['dashboard_widget_system_info'], __( 'Server Information widget (includes a live server clock)', 'emmytech-admin-pro' ) ); ?>
					<?php $this->checkbox_field( 'replace_dashboard', $s['replace_dashboard'], __( 'Hide the default WordPress widgets and welcome panel (At a Glance, Activity, Site Health, Quick Draft, Events and News)', 'emmytech-admin-pro' ) ); ?>
				</div>

				<div class="emmytech-setting-card">
					<h2><?php esc_html_e( 'Site Statistics — cards & order', 'emmytech-admin-pro' ); ?></h2>
					<?php $this->render_sortable_checklist( 'dashboard_stats', $stat_catalog, (array) $s['dashboard_stats'] ); ?>
				</div>

				<div class="emmytech-setting-card">
					<h2><?php esc_html_e( 'Quick Actions — links & order', 'emmytech-admin-pro' ); ?></h2>
					<?php $this->render_sortable_checklist( 'quick_actions', $action_catalog, (array) $s['quick_actions'] ); ?>
				</div>

				<div class="emmytech-setting-card">
					<h2><?php esc_html_e( 'Activity Feed — event types & order', 'emmytech-admin-pro' ); ?></h2>
					<p class="description"><?php esc_html_e( 'Choose which kinds of activity appear in the feed, and in what priority order when several happen close together.', 'emmytech-admin-pro' ); ?></p>
					<?php $this->render_sortable_checklist( 'activity_feed_types', $activity_catalog, (array) $s['activity_feed_types'] ); ?>

					<label for="activity_feed_limit"><?php esc_html_e( 'Number of items to show', 'emmytech-admin-pro' ); ?></label>
					<input type="number" id="activity_feed_limit" name="activity_feed_limit" min="3" max="20" value="<?php echo esc_attr( $s['activity_feed_limit'] ); ?>">
				</div>

				<div class="emmytech-setting-card">
					<h2><?php esc_html_e( 'Server Information', 'emmytech-admin-pro' ); ?></h2>
					<?php $this->checkbox_field( 'server_info_show_clock', $s['server_info_show_clock'], __( 'Show a live, ticking server clock at the top of the widget', 'emmytech-admin-pro' ) ); ?>
				</div>

				<?php $this->submit_button( __( 'Save Dashboard Settings', 'emmytech-admin-pro' ) ); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Renders a drag-to-reorder checklist shared by the Stats and Quick
	 * Actions sections. Enabled items (in their saved order) are listed
	 * first, followed by any remaining catalog items, so nothing a
	 * developer adds via filter is ever invisible to the site owner.
	 *
	 * @param string $group    'dashboard_stats', 'quick_actions', or 'activity_feed_types'.
	 * @param array  $catalog  key => array{label:string,...}.
	 * @param array  $enabled  Ordered list of currently-enabled keys.
	 */
	private function render_sortable_checklist( $group, array $catalog, array $enabled ) {
		$enabled   = array_values( array_intersect( $enabled, array_keys( $catalog ) ) );
		$remaining = array_diff( array_keys( $catalog ), $enabled );
		$ordered   = array_merge( $enabled, array_values( $remaining ) );
		?>
		<ul class="emmytech-sortable-list" data-order-field="<?php echo esc_attr( $group . '_order' ); ?>">
			<?php foreach ( $ordered as $key ) : ?>
				<li data-key="<?php echo esc_attr( $key ); ?>">
					<span class="emmytech-drag-handle dashicons dashicons-menu" aria-hidden="true"></span>
					<label>
						<input type="checkbox" name="<?php echo esc_attr( $group ); ?>_enabled[]" value="<?php echo esc_attr( $key ); ?>" <?php checked( in_array( $key, $enabled, true ) ); ?>>
						<?php echo esc_html( $catalog[ $key ]['label'] ); ?>
					</label>
				</li>
			<?php endforeach; ?>
		</ul>
		<input type="hidden" name="<?php echo esc_attr( $group ); ?>_order" class="emmytech-order-field" value="<?php echo esc_attr( implode( ',', $ordered ) ); ?>">
		<?php
	}

	/* ================================================================
	 * Page: Tools (menu decluttering, login redirect, export/import/reset)
	 * ============================================================== */

	public function render_tools_page() {
		$this->guard();
		$s = $this->settings->all();

		$import_status = isset( $_GET['emmytech_import'] ) ? sanitize_key( wp_unslash( $_GET['emmytech_import'] ) ) : '';
		$reset_status  = isset( $_GET['emmytech_reset'] ) ? sanitize_key( wp_unslash( $_GET['emmytech_reset'] ) ) : '';
		?>
		<div class="wrap emmytech-settings">
			<h1><?php esc_html_e( 'Tools', 'emmytech-admin-pro' ); ?></h1>
			<p class="emmytech-intro"><?php esc_html_e( 'Advanced options: declutter the admin menu, redirect users after login, and back up your EmmyTech configuration.', 'emmytech-admin-pro' ); ?></p>

			<?php $this->render_submenu_nav( 'emmytech-tools' ); ?>

			<?php if ( 'success' === $import_status ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Settings imported successfully.', 'emmytech-admin-pro' ); ?></p></div>
			<?php elseif ( 'error' === $import_status ) : ?>
				<div class="notice notice-error is-dismissible"><p><?php esc_html_e( 'That file could not be imported. Please upload a valid EmmyTech Admin Pro export.', 'emmytech-admin-pro' ); ?></p></div>
			<?php endif; ?>
			<?php if ( 'success' === $reset_status ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'All EmmyTech settings were reset to their defaults.', 'emmytech-admin-pro' ); ?></p></div>
			<?php endif; ?>

			<form method="post">
				<?php $this->nonce_field(); ?>

				<div class="emmytech-setting-card">
					<h2><?php esc_html_e( 'Declutter Admin Menu', 'emmytech-admin-pro' ); ?></h2>
					<label for="hidden_menu_slugs"><?php esc_html_e( 'Menu slugs to hide (one per line)', 'emmytech-admin-pro' ); ?></label>
					<textarea class="large-text code" id="hidden_menu_slugs" name="hidden_menu_slugs" rows="4" placeholder="edit-comments.php&#10;tools.php"><?php echo esc_textarea( implode( "\n", (array) $s['hidden_menu_slugs'] ) ); ?></textarea>
					<p class="description"><?php esc_html_e( 'Example slugs: edit-comments.php, tools.php, edit.php?post_type=page. This only hides the menu link — it does not change what any user is allowed to do, and the Dashboard and EmmyTech menus can never be hidden.', 'emmytech-admin-pro' ); ?></p>
				</div>

				<div class="emmytech-setting-card">
					<h2><?php esc_html_e( 'Login Redirect', 'emmytech-admin-pro' ); ?></h2>
					<label for="login_redirect_url"><?php esc_html_e( 'Redirect URL after login', 'emmytech-admin-pro' ); ?></label>
					<input class="regular-text" type="url" id="login_redirect_url" name="login_redirect_url" value="<?php echo esc_attr( $s['login_redirect_url'] ); ?>" placeholder="https://example.com/welcome/">
					<p class="description"><?php esc_html_e( 'Leave empty to use the normal WordPress behavior. Ignored whenever a user was already headed to a specific page (e.g. from a "please log in" link).', 'emmytech-admin-pro' ); ?></p>
					<?php $this->checkbox_field( 'login_redirect_admins', $s['login_redirect_admins'], __( 'Also redirect administrators (off by default, so admins always land in wp-admin)', 'emmytech-admin-pro' ) ); ?>
				</div>

				<?php $this->submit_button( __( 'Save Tools Settings', 'emmytech-admin-pro' ) ); ?>
			</form>

			<div class="emmytech-setting-card">
				<h2><?php esc_html_e( 'Backup & Reset', 'emmytech-admin-pro' ); ?></h2>

				<p>
					<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=emmytech_export_settings' ), 'emmytech_export_settings' ) ); ?>"><?php esc_html_e( 'Export Settings (JSON)', 'emmytech-admin-pro' ); ?></a>
				</p>

				<form method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="emmytech_import_settings">
					<?php wp_nonce_field( 'emmytech_import_settings' ); ?>
					<label for="emmytech_import_file"><?php esc_html_e( 'Import Settings', 'emmytech-admin-pro' ); ?></label>
					<input type="file" id="emmytech_import_file" name="emmytech_import_file" accept="application/json">
					<p><button type="submit" class="button"><?php esc_html_e( 'Upload & Import', 'emmytech-admin-pro' ); ?></button></p>
				</form>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="emmytech-reset-form">
					<input type="hidden" name="action" value="emmytech_reset_settings">
					<?php wp_nonce_field( 'emmytech_reset_settings' ); ?>
					<p><button type="submit" class="button button-link-delete"><?php esc_html_e( 'Reset All Settings to Defaults', 'emmytech-admin-pro' ); ?></button></p>
				</form>
			</div>
		</div>
		<?php
	}

	/* ================================================================
	 * Page: About
	 * ============================================================== */

	public function render_about_page() {
		$this->guard();
		global $wp_version;
		?>
		<div class="wrap emmytech-settings">
			<h1><?php esc_html_e( 'About EmmyTech Admin Pro', 'emmytech-admin-pro' ); ?></h1>

			<?php $this->render_submenu_nav( 'emmytech-about' ); ?>

			<div class="emmytech-setting-card">
				<h2><?php esc_html_e( 'Version', 'emmytech-admin-pro' ); ?></h2>
				<p><?php echo esc_html( EMMYTECH_PRO_VERSION ); ?> — <?php esc_html_e( 'running on WordPress', 'emmytech-admin-pro' ); ?> <?php echo esc_html( $wp_version ); ?> / <?php esc_html_e( 'PHP', 'emmytech-admin-pro' ); ?> <?php echo esc_html( phpversion() ); ?></p>
			</div>

			<div class="emmytech-setting-card">
				<h2><?php esc_html_e( 'Changelog', 'emmytech-admin-pro' ); ?></h2>
				<dl class="emmytech-changelog">
					<dt>3.4.0</dt>
					<dd><?php esc_html_e( 'New Activity Feed widget: a merged, live-updating timeline of recent posts, comments, user registrations, and logins — choose which event types appear and in what order, and how many to show, under EmmyTech → Dashboard. Timestamps across the feed tick forward on their own ("5 minutes ago" becomes "6 minutes ago") without a page reload. Server Information widget expanded with a live server clock, database version, server software, PHP extensions, max execution time, timezone, and debug-mode status. Visual polish pass for a more seamless feel: smoother widget chrome, hover states, and consistent focus outlines throughout.', 'emmytech-admin-pro' ); ?></dd>
					<dt>3.3.0</dt>
					<dd><?php esc_html_e( 'The EmmyTech widgets now are the Dashboard. New "At a glance" layout (default): every widget on one full-width responsive grid instead of a single narrow column, with compact stat cards, the three charts side by side, and no dead space when a widget is switched off. WordPress\'s default widgets, including Site Health and Events and News, and the welcome panel are hidden. The classic draggable layout stays available under EmmyTech → Dashboard. Fixed: the Content Mix and Content Growth charts did not draw, and chart colors are now readable on the light dashboard cards.', 'emmytech-admin-pro' ); ?></dd>
					<dt>3.2.0</dt>
					<dd><?php esc_html_e( 'New chart-driven dashboard visuals: Today\'s Highlights (trend stat cards), Weekly Publishing Activity (bar chart), Content Mix (donut chart), Content Growth (12-month line chart), Top Content (most-commented posts), and Upcoming Schedule. Stat cards now use colored icon badges. Charts are rendered with a locally-bundled Chart.js — no external requests. Weekly/monthly chart queries are cached in transients and auto-invalidated when content changes.', 'emmytech-admin-pro' ); ?></dd>
				<dt>3.1.0</dt>
					<dd><?php esc_html_e( 'Modular rebuild. Fully customizable dashboard (choose & reorder stat cards and quick actions; four independent, drag-to-reorder widgets). New Tools page: admin-menu decluttering, post-login redirect, JSON settings export/import, one-click reset. Developer filters for extending stats and quick actions.', 'emmytech-admin-pro' ); ?></dd>
					<dt>3.0.0</dt>
					<dd><?php esc_html_e( 'Consolidated settings storage, live-preview Appearance page, richer dashboard statistics, proper uninstall.php.', 'emmytech-admin-pro' ); ?></dd>
					<dt>2.0.0</dt>
					<dd><?php esc_html_e( 'Initial branded admin/login customization release.', 'emmytech-admin-pro' ); ?></dd>
				</dl>
			</div>

			<div class="emmytech-setting-card">
				<h2><?php esc_html_e( 'Extending EmmyTech Admin Pro', 'emmytech-admin-pro' ); ?></h2>
				<p><?php esc_html_e( 'Other plugins or a theme\'s functions.php can add their own dashboard stat cards, quick-action links, or activity feed event types using these filters:', 'emmytech-admin-pro' ); ?></p>
				<pre class="emmytech-code">add_filter( 'emmytech_pro_dashboard_stats', function ( $catalog ) {
    $catalog['my_stat'] = array(
        'label' => 'My Stat',
        'icon'  => 'dashicons-chart-line',
        'color' => '#5b8def',
        'value' => function () { return 42; },
    );
    return $catalog;
} );

add_filter( 'emmytech_pro_quick_actions', function ( $catalog ) {
    $catalog['my_link'] = array(
        'label'      => 'My Tool',
        'icon'       => 'dashicons-admin-tools',
        'url'        => function () { return admin_url( 'admin.php?page=my-tool' ); },
        'capability' => 'manage_options',
    );
    return $catalog;
} );

add_filter( 'emmytech_pro_activity_feed_types', function ( $catalog ) {
    $catalog['my_event'] = array(
        'label'      => 'My Events',
        'icon'       => 'dashicons-flag',
        'color'      => '#e67e22',
        'capability' => 'manage_options',
        // Must return entries shaped like: array( 'title' => ..., 'meta' => ..., 'link' => ..., 'timestamp' => unix_time ).
        'fetch'      => function ( $limit ) { return array(); },
    );
    return $catalog;
} );</pre>
			</div>
		</div>
		<?php
	}

	/* ================================================================
	 * Small shared view helpers
	 * ============================================================== */

	private function guard() {
		if ( ! current_user_can( EmmyTech_Settings::capability() ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'emmytech-admin-pro' ) );
		}
	}

	private function nonce_field() {
		wp_nonce_field( self::NONCE_ACTION, self::NONCE_FIELD );
	}

	private function submit_button( $label = '' ) {
		$label = '' !== $label ? $label : __( 'Save EmmyTech Settings', 'emmytech-admin-pro' );
		echo '<p><button type="submit" name="emmytech_save" value="1" class="button button-primary button-hero">' . esc_html( $label ) . '</button></p>';
	}

	private function checkbox_field( $name, $current_value, $label, $id = '' ) {
		$id = $id ? $id : $name;
		?>
		<input type="hidden" name="emmytech_field_<?php echo esc_attr( $name ); ?>" value="1">
		<label><input type="checkbox" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="1" <?php checked( $current_value, '1' ); ?>> <?php echo esc_html( $label ); ?></label>
		<?php
	}

	/**
	 * Simple tab-style navigation across the five EmmyTech screens.
	 *
	 * @param string $current_slug
	 */
	private function render_submenu_nav( $current_slug ) {
		$tabs = array(
			'emmytech-control-center'     => __( 'Control Center', 'emmytech-admin-pro' ),
			'emmytech-admin-appearance'   => __( 'Appearance', 'emmytech-admin-pro' ),
			'emmytech-dashboard-settings' => __( 'Dashboard', 'emmytech-admin-pro' ),
			'emmytech-tools'              => __( 'Tools', 'emmytech-admin-pro' ),
			'emmytech-about'              => __( 'About', 'emmytech-admin-pro' ),
		);
		echo '<nav class="emmytech-tabs">';
		foreach ( $tabs as $slug => $label ) {
			$class = $slug === $current_slug ? 'emmytech-tab is-active' : 'emmytech-tab';
			echo '<a class="' . esc_attr( $class ) . '" href="' . esc_url( admin_url( 'admin.php?page=' . $slug ) ) . '">' . esc_html( $label ) . '</a>';
		}
		echo '</nav>';
	}
}
