<?php
/**
 * Dashboard module for EmmyTech Admin Pro.
 *
 * Registers up to eleven independent dashboard widgets instead of one
 * monolithic box: Welcome, Today's Highlights, Site Statistics, Weekly
 * Publishing Activity (bar chart), Content Mix (donut chart), Content
 * Growth (line chart), Top Content, Upcoming Schedule, Activity Feed,
 * Quick Actions, and Server Information. Because each is a normal
 * wp_add_dashboard_widget() box, WordPress core already gives users native
 * drag-to-reorder, collapse, and per-widget show/hide through the
 * Dashboard's own Screen Options tab.
 *
 * The Stats, Quick Actions, and Activity Feed widgets go further: site
 * owners choose which cards/links/event types appear and in what order
 * (see EmmyTech_Admin_Pages::render_dashboard_page()), and other plugins
 * can register their own entries via the three catalog filters below.
 *
 * All data comes from documented WordPress query APIs (WP_Query,
 * WP_Comment_Query, WP_User_Query, wp_count_posts/comments, $wpdb's own
 * db_version() method) — no direct database access. The heavier chart and
 * activity-feed queries are cached in transients and invalidated
 * automatically whenever content, comments, registrations, or logins
 * change. WordPress does not track logins on its own, so a prefixed user
 * meta value recorded on the documented 'wp_login' hook powers the
 * Activity Feed's "user activity" entries.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EmmyTech_Dashboard {

	/** @var EmmyTech_Settings */
	private $settings;

	public function __construct( EmmyTech_Settings $settings ) {
		$this->settings = $settings;

		add_action( 'wp_dashboard_setup', array( $this, 'register_widgets' ), 100 );

		// Keep the cached chart/activity data fresh whenever content changes.
		foreach ( array( 'save_post', 'deleted_post', 'trashed_post', 'untrashed_post', 'wp_insert_comment', 'user_register' ) as $hook ) {
			add_action( $hook, array( $this, 'invalidate_caches' ) );
		}

		// WordPress does not track logins on its own; a prefixed user meta
		// value recorded on the documented 'wp_login' hook is what powers
		// the "user activity" entries in the Activity Feed widget.
		add_action( 'wp_login', array( $this, 'record_login' ), 10, 2 );
	}

	public function invalidate_caches() {
		delete_transient( 'emmytech_pro_weekly_activity' );
		delete_transient( 'emmytech_pro_content_growth' );
		delete_transient( 'emmytech_pro_activity_feed' );
	}

	/**
	 * Records the current user's last-login time so the Activity Feed can
	 * show "so-and-so logged in" entries. Stores only a timestamp under a
	 * plugin-prefixed meta key — no session data, no IP address.
	 *
	 * @param string  $user_login
	 * @param WP_User $user
	 */
	public function record_login( $user_login, $user ) {
		if ( $user instanceof WP_User ) {
			update_user_meta( $user->ID, '_emmytech_pro_last_login', time() );
		}
		$this->invalidate_caches();
	}

	/* ================================================================
	 * Filterable catalogs
	 * ============================================================== */

	/**
	 * Catalog of stat cards available for the Stats widget. Filterable so
	 * other plugins/mu-plugins can contribute their own numbers (e.g. a
	 * WooCommerce sales total) without touching this plugin's code.
	 *
	 * Each entry: label, an icon (Dashicon slug), an accent color, and a
	 * value callable returning a scalar.
	 *
	 * @return array<string,array{label:string,icon:string,color:string,value:callable}>
	 */
	public static function stat_catalog() {
		$catalog = array(
			'posts_published'   => array(
				'label' => __( 'Published Posts', 'emmytech-admin-pro' ),
				'icon'  => 'dashicons-admin-post',
				'color' => '#5b8def',
				'value' => function () {
					$counts = wp_count_posts( 'post' );
					return isset( $counts->publish ) ? (int) $counts->publish : 0;
				},
			),
			'posts_draft'       => array(
				'label' => __( 'Draft Posts', 'emmytech-admin-pro' ),
				'icon'  => 'dashicons-edit',
				'color' => '#f5a623',
				'value' => function () {
					$counts = wp_count_posts( 'post' );
					return isset( $counts->draft ) ? (int) $counts->draft : 0;
				},
			),
			'pages_published'   => array(
				'label' => __( 'Published Pages', 'emmytech-admin-pro' ),
				'icon'  => 'dashicons-admin-page',
				'color' => '#17c3b2',
				'value' => function () {
					$counts = wp_count_posts( 'page' );
					return isset( $counts->publish ) ? (int) $counts->publish : 0;
				},
			),
			'comments_approved' => array(
				'label' => __( 'Approved Comments', 'emmytech-admin-pro' ),
				'icon'  => 'dashicons-admin-comments',
				'color' => '#2ecc71',
				'value' => function () {
					$counts = wp_count_comments();
					return isset( $counts->approved ) ? (int) $counts->approved : 0;
				},
			),
			'comments_pending'  => array(
				'label' => __( 'Pending Comments', 'emmytech-admin-pro' ),
				'icon'  => 'dashicons-warning',
				'color' => '#e67e22',
				'value' => function () {
					$counts = wp_count_comments();
					return isset( $counts->moderated ) ? (int) $counts->moderated : 0;
				},
			),
			'media_count'       => array(
				'label' => __( 'Media Items', 'emmytech-admin-pro' ),
				'icon'  => 'dashicons-admin-media',
				'color' => '#9b59b6',
				'value' => function () {
					$counts = wp_count_posts( 'attachment' );
					return isset( $counts->inherit ) ? (int) $counts->inherit : 0;
				},
			),
			'total_users'       => array(
				'label' => __( 'Total Users', 'emmytech-admin-pro' ),
				'icon'  => 'dashicons-admin-users',
				'color' => '#e84393',
				'value' => function () {
					$users = count_users();
					return isset( $users['total_users'] ) ? (int) $users['total_users'] : 0;
				},
			),
			'active_plugins'    => array(
				'label' => __( 'Active Plugins', 'emmytech-admin-pro' ),
				'icon'  => 'dashicons-admin-plugins',
				'color' => '#607d8b',
				'value' => function () {
					return count( (array) get_option( 'active_plugins', array() ) );
				},
			),
		);

		/**
		 * Filters the catalog of stat cards available on the EmmyTech
		 * dashboard widget.
		 *
		 * @param array $catalog key => array{label:string,icon:string,color:string,value:callable}
		 */
		return apply_filters( 'emmytech_pro_dashboard_stats', $catalog );
	}

	/**
	 * Catalog of links available for the Quick Actions widget. Each entry
	 * declares the capability required so a link never appears to a user
	 * who couldn't use it anyway.
	 *
	 * @return array<string,array{label:string,icon:string,url:callable,capability:string}>
	 */
	public static function quick_action_catalog() {
		$catalog = array(
			'new_post' => array(
				'label'      => __( 'New Post', 'emmytech-admin-pro' ),
				'icon'       => 'dashicons-edit-large',
				'url'        => function () {
					return admin_url( 'post-new.php' );
				},
				'capability' => 'edit_posts',
			),
			'new_page' => array(
				'label'      => __( 'New Page', 'emmytech-admin-pro' ),
				'icon'       => 'dashicons-admin-page',
				'url'        => function () {
					return admin_url( 'post-new.php?post_type=page' );
				},
				'capability' => 'edit_pages',
			),
			'media'    => array(
				'label'      => __( 'Media', 'emmytech-admin-pro' ),
				'icon'       => 'dashicons-admin-media',
				'url'        => function () {
					return admin_url( 'upload.php' );
				},
				'capability' => 'upload_files',
			),
			'users'    => array(
				'label'      => __( 'Users', 'emmytech-admin-pro' ),
				'icon'       => 'dashicons-admin-users',
				'url'        => function () {
					return admin_url( 'users.php' );
				},
				'capability' => 'list_users',
			),
			'plugins'  => array(
				'label'      => __( 'Plugins', 'emmytech-admin-pro' ),
				'icon'       => 'dashicons-admin-plugins',
				'url'        => function () {
					return admin_url( 'plugins.php' );
				},
				'capability' => 'activate_plugins',
			),
			'comments' => array(
				'label'      => __( 'Comments', 'emmytech-admin-pro' ),
				'icon'       => 'dashicons-admin-comments',
				'url'        => function () {
					return admin_url( 'edit-comments.php' );
				},
				'capability' => 'moderate_comments',
			),
			'settings' => array(
				'label'      => __( 'EmmyTech Settings', 'emmytech-admin-pro' ),
				'icon'       => 'dashicons-admin-customizer',
				'url'        => function () {
					return admin_url( 'admin.php?page=emmytech-control-center' );
				},
				'capability' => EmmyTech_Settings::capability(),
			),
			'profile'  => array(
				'label'      => __( 'My Profile', 'emmytech-admin-pro' ),
				'icon'       => 'dashicons-nametag',
				'url'        => function () {
					return admin_url( 'profile.php' );
				},
				'capability' => 'read',
			),
		);

		/**
		 * Filters the catalog of quick-action links available on the
		 * EmmyTech dashboard widget.
		 *
		 * @param array $catalog key => array{label:string,icon:string,url:callable,capability:string}
		 */
		return apply_filters( 'emmytech_pro_quick_actions', $catalog );
	}

	/**
	 * Catalog of event types the Activity Feed widget can show. Filterable
	 * so other plugins can contribute their own activity type (e.g. an
	 * e-commerce plugin adding "orders"). Each type's `fetch` callable
	 * returns a flat array of normalized entries (see get_activity_feed()).
	 *
	 * @return array<string,array{label:string,icon:string,color:string,capability:string,fetch:callable}>
	 */
	public static function activity_type_catalog() {
		$catalog = array(
			'posts'            => array(
				'label'      => __( 'New Posts', 'emmytech-admin-pro' ),
				'icon'       => 'dashicons-admin-post',
				'color'      => '#5b8def',
				'capability' => 'edit_posts',
				'fetch'      => array( __CLASS__, 'fetch_activity_posts' ),
			),
			'comments'         => array(
				'label'      => __( 'New Comments', 'emmytech-admin-pro' ),
				'icon'       => 'dashicons-admin-comments',
				'color'      => '#2ecc71',
				'capability' => 'moderate_comments',
				'fetch'      => array( __CLASS__, 'fetch_activity_comments' ),
			),
			'users_registered' => array(
				'label'      => __( 'New User Registrations', 'emmytech-admin-pro' ),
				'icon'       => 'dashicons-admin-users',
				'color'      => '#e84393',
				'capability' => 'list_users',
				'fetch'      => array( __CLASS__, 'fetch_activity_registrations' ),
			),
			'users_login'      => array(
				'label'      => __( 'User Logins', 'emmytech-admin-pro' ),
				'icon'       => 'dashicons-unlock',
				'color'      => '#9b59b6',
				'capability' => 'list_users',
				'fetch'      => array( __CLASS__, 'fetch_activity_logins' ),
			),
		);

		/**
		 * Filters the catalog of event types available in the EmmyTech
		 * Activity Feed widget.
		 *
		 * @param array $catalog key => array{label,icon,color,capability,fetch}
		 */
		return apply_filters( 'emmytech_pro_activity_feed_types', $catalog );
	}

	/* ================================================================
	 * Widget registration
	 * ============================================================== */

	/**
	 * WordPress's own dashboard widgets. Removed when "replace_dashboard"
	 * is on, so the EmmyTech widgets are the whole dashboard. The PHP /
	 * browser upgrade nags are deliberately NOT in this list: they are
	 * security warnings, not decoration.
	 *
	 * @return array<string,string> widget id => context it is registered in.
	 */
	private static function core_widgets() {
		return array(
			'dashboard_right_now'   => 'normal', // At a Glance.
			'dashboard_activity'    => 'normal', // Activity.
			'dashboard_site_health' => 'normal', // Site Health Status.
			'dashboard_quick_press' => 'side',   // Quick Draft.
			'dashboard_primary'     => 'side',   // WordPress Events and News.
		);
	}

	public function register_widgets() {
		// Users who can't see the EmmyTech widgets keep WordPress's own
		// dashboard, rather than being left with an empty screen.
		if ( ! current_user_can( 'edit_posts' ) ) {
			return;
		}

		if ( '1' === $this->settings->get( 'replace_dashboard', '1' ) ) {
			foreach ( self::core_widgets() as $id => $context ) {
				remove_meta_box( $id, 'dashboard', $context );
			}
		}

		$widgets = array(
			'dashboard_widget_hero'            => array( 'emmytech_pro_hero', __( 'EmmyTech · Welcome', 'emmytech-admin-pro' ), 'render_hero_widget' ),
			'dashboard_widget_highlights'       => array( 'emmytech_pro_highlights', __( "EmmyTech · Today's Highlights", 'emmytech-admin-pro' ), 'render_highlights_widget' ),
			'dashboard_widget_stats'            => array( 'emmytech_pro_stats', __( 'EmmyTech · Site Statistics', 'emmytech-admin-pro' ), 'render_stats_widget' ),
			'dashboard_widget_weekly_activity'  => array( 'emmytech_pro_weekly_activity', __( 'EmmyTech · Weekly Publishing Activity', 'emmytech-admin-pro' ), 'render_weekly_activity_widget' ),
			'dashboard_widget_content_mix'      => array( 'emmytech_pro_content_mix', __( 'EmmyTech · Content Mix', 'emmytech-admin-pro' ), 'render_content_mix_widget' ),
			'dashboard_widget_content_growth'   => array( 'emmytech_pro_content_growth', __( 'EmmyTech · Content Growth', 'emmytech-admin-pro' ), 'render_content_growth_widget' ),
			'dashboard_widget_top_content'      => array( 'emmytech_pro_top_content', __( 'EmmyTech · Top Content', 'emmytech-admin-pro' ), 'render_top_content_widget' ),
			'dashboard_widget_schedule'         => array( 'emmytech_pro_schedule', __( 'EmmyTech · Upcoming Schedule', 'emmytech-admin-pro' ), 'render_schedule_widget' ),
			'dashboard_widget_activity'         => array( 'emmytech_pro_activity', __( 'EmmyTech · Activity Feed', 'emmytech-admin-pro' ), 'render_activity_widget' ),
			'dashboard_widget_quick_actions'    => array( 'emmytech_pro_quick_actions', __( 'EmmyTech · Quick Actions', 'emmytech-admin-pro' ), 'render_quick_actions_widget' ),
		);

		foreach ( $widgets as $setting_key => $widget ) {
			if ( '1' !== $this->settings->get( $setting_key, '1' ) ) {
				continue;
			}
			// The Upcoming Schedule widget lists future posts across all
			// authors, so it requires the capability to see others' work
			// (matching how WordPress core's own admin screens behave),
			// not just the ability to edit one's own posts.
			if ( 'dashboard_widget_schedule' === $setting_key && ! current_user_can( 'edit_others_posts' ) ) {
				continue;
			}
			wp_add_dashboard_widget( $widget[0], $widget[1], array( $this, $widget[2] ) );
		}

		if ( '1' === $this->settings->get( 'dashboard_widget_system_info', '1' ) && current_user_can( EmmyTech_Settings::capability() ) ) {
			wp_add_dashboard_widget( 'emmytech_pro_system_info', __( 'EmmyTech · Server Information', 'emmytech-admin-pro' ), array( $this, 'render_system_info_widget' ) );
		}
	}

	/* ================================================================
	 * Data queries (WP_Query / WP_Comment_Query / WP_User_Query only)
	 * ============================================================== */

	/**
	 * Counts posts of a given type whose local post_date falls within an
	 * inclusive day range, using WP_Query's own found-rows count rather
	 * than a raw SQL COUNT.
	 *
	 * @param string $post_type
	 * @param string $after  'Y-m-d H:i:s'
	 * @param string $before 'Y-m-d H:i:s'
	 * @return int
	 */
	private function count_posts_between( $post_type, $after, $before ) {
		$query = new WP_Query( array(
			'post_type'              => $post_type,
			'post_status'            => 'publish',
			'fields'                 => 'ids',
			'posts_per_page'         => 1,
			'no_found_rows'          => false,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
			'date_query'             => array(
				array(
					'column'    => 'post_date',
					'after'     => $after,
					'before'    => $before,
					'inclusive' => true,
				),
			),
		) );
		return (int) $query->found_posts;
	}

	private function count_comments_between( $after, $before ) {
		$query = new WP_Comment_Query( array(
			'count'      => true,
			'status'     => 'approve',
			'date_query' => array(
				array(
					'column'    => 'comment_date',
					'after'     => $after,
					'before'    => $before,
					'inclusive' => true,
				),
			),
		) );
		return (int) $query->get_comments();
	}

	private function count_users_between( $after, $before ) {
		$query = new WP_User_Query( array(
			'count_total' => true,
			'fields'      => 'ID',
			'number'      => 1,
			'date_query'  => array(
				array(
					'after'     => $after,
					'before'    => $before,
					'inclusive' => true,
				),
			),
		) );
		return (int) $query->get_total();
	}

	/**
	 * Today-vs-yesterday counts for the Highlights widget. Deliberately
	 * uncached (it must reflect "today"), but every underlying query is
	 * a single indexed-range lookup, which is cheap even on a fairly
	 * busy site and only ever runs on the wp-admin Dashboard screen.
	 *
	 * @return array
	 */
	public function get_highlights() {
		$today_start     = current_time( 'Y-m-d 00:00:00' );
		$today_end       = current_time( 'Y-m-d 23:59:59' );
		$yesterday_start = date( 'Y-m-d 00:00:00', strtotime( '-1 day', current_time( 'timestamp' ) ) );
		$yesterday_end   = date( 'Y-m-d 23:59:59', strtotime( '-1 day', current_time( 'timestamp' ) ) );

		$cards = array(
			'posts'    => array(
				'label'      => __( 'Posts Today', 'emmytech-admin-pro' ),
				'icon'       => 'dashicons-admin-post',
				'color'      => '#5b8def',
				'capability' => 'edit_posts',
				'today'      => $this->count_posts_between( 'post', $today_start, $today_end ),
				'yesterday'  => $this->count_posts_between( 'post', $yesterday_start, $yesterday_end ),
			),
			'comments' => array(
				'label'      => __( 'Comments Today', 'emmytech-admin-pro' ),
				'icon'       => 'dashicons-admin-comments',
				'color'      => '#2ecc71',
				'capability' => 'moderate_comments',
				'today'      => $this->count_comments_between( $today_start, $today_end ),
				'yesterday'  => $this->count_comments_between( $yesterday_start, $yesterday_end ),
			),
			'media'    => array(
				'label'      => __( 'Media Today', 'emmytech-admin-pro' ),
				'icon'       => 'dashicons-admin-media',
				'color'      => '#9b59b6',
				'capability' => 'upload_files',
				'today'      => $this->count_posts_between( 'attachment', $today_start, $today_end ),
				'yesterday'  => $this->count_posts_between( 'attachment', $yesterday_start, $yesterday_end ),
			),
			'users'    => array(
				'label'      => __( 'New Users Today', 'emmytech-admin-pro' ),
				'icon'       => 'dashicons-admin-users',
				'color'      => '#e84393',
				'capability' => 'list_users',
				'today'      => $this->count_users_between( $today_start, $today_end ),
				'yesterday'  => $this->count_users_between( $yesterday_start, $yesterday_end ),
			),
		);

		foreach ( $cards as &$card ) {
			if ( $card['yesterday'] > 0 ) {
				$card['trend'] = round( ( ( $card['today'] - $card['yesterday'] ) / $card['yesterday'] ) * 100 );
			} elseif ( $card['today'] > 0 ) {
				$card['trend'] = null; // "New" — no meaningful percentage from a zero base.
			} else {
				$card['trend'] = 0;
			}
		}
		unset( $card );

		return $cards;
	}

	/**
	 * Published-posts-per-day for the last 7 days, cached for 3 hours.
	 *
	 * @return array{labels:array,data:array}
	 */
	public function get_weekly_activity() {
		$cached = get_transient( 'emmytech_pro_weekly_activity' );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		$labels = array();
		$data   = array();
		$now    = current_time( 'timestamp' );

		for ( $i = 6; $i >= 0; $i-- ) {
			$day_ts   = strtotime( "-{$i} days", $now );
			$labels[] = date_i18n( 'D', $day_ts );
			$data[]   = $this->count_posts_between( 'post', date( 'Y-m-d 00:00:00', $day_ts ), date( 'Y-m-d 23:59:59', $day_ts ) );
		}

		$result = array( 'labels' => $labels, 'data' => $data );
		set_transient( 'emmytech_pro_weekly_activity', $result, 3 * HOUR_IN_SECONDS );
		return $result;
	}

	/**
	 * Published-posts-per-month for the last 12 months, cached for 12 hours.
	 *
	 * @return array{labels:array,data:array}
	 */
	public function get_content_growth() {
		$cached = get_transient( 'emmytech_pro_content_growth' );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		$labels = array();
		$data   = array();
		$now    = current_time( 'timestamp' );

		for ( $i = 11; $i >= 0; $i-- ) {
			$month_ts   = strtotime( "-{$i} months", $now );
			$year       = (int) date( 'Y', $month_ts );
			$month      = (int) date( 'n', $month_ts );
			$days_in    = (int) date( 't', $month_ts );
			$labels[]   = date_i18n( 'M', $month_ts );
			$data[]     = $this->count_posts_between(
				'post',
				sprintf( '%04d-%02d-01 00:00:00', $year, $month ),
				sprintf( '%04d-%02d-%02d 23:59:59', $year, $month, $days_in )
			);
		}

		$result = array( 'labels' => $labels, 'data' => $data );
		set_transient( 'emmytech_pro_content_growth', $result, 12 * HOUR_IN_SECONDS );
		return $result;
	}

	/**
	 * Published post/page/media counts for the donut chart. Backed by
	 * wp_count_posts(), which core already caches — no transient needed.
	 *
	 * @return array{labels:array,data:array,percent:int}
	 */
	public function get_content_mix() {
		$posts = wp_count_posts( 'post' );
		$pages = wp_count_posts( 'page' );
		$media = wp_count_posts( 'attachment' );

		$counts = array(
			'posts' => isset( $posts->publish ) ? (int) $posts->publish : 0,
			'pages' => isset( $pages->publish ) ? (int) $pages->publish : 0,
			'media' => isset( $media->inherit ) ? (int) $media->inherit : 0,
		);
		$total = array_sum( $counts );
		$percent = $total > 0 ? round( ( $counts['posts'] / $total ) * 100 ) : 0;

		return array(
			'labels'  => array( __( 'Posts', 'emmytech-admin-pro' ), __( 'Pages', 'emmytech-admin-pro' ), __( 'Media', 'emmytech-admin-pro' ) ),
			'data'    => array_values( $counts ),
			'percent' => $percent,
		);
	}

	/**
	 * Top 5 published posts by comment count.
	 *
	 * @return array
	 */
	public function get_top_content() {
		$query = new WP_Query( array(
			'post_type'              => 'post',
			'post_status'            => 'publish',
			'posts_per_page'         => 5,
			'orderby'                => 'comment_count',
			'order'                  => 'DESC',
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
		) );

		$max = 1;
		foreach ( $query->posts as $post ) {
			$max = max( $max, (int) $post->comment_count );
		}

		$rows = array();
		foreach ( $query->posts as $post ) {
			$rows[] = array(
				'title'   => get_the_title( $post ),
				'edit'    => get_edit_post_link( $post, 'raw' ),
				'count'   => (int) $post->comment_count,
				'percent' => round( ( (int) $post->comment_count / $max ) * 100 ),
			);
		}
		return $rows;
	}

	/**
	 * Next 5 scheduled ("future") posts.
	 *
	 * @return array
	 */
	public function get_upcoming_schedule() {
		$query = new WP_Query( array(
			'post_type'              => array( 'post', 'page' ),
			'post_status'            => 'future',
			'posts_per_page'         => 5,
			'orderby'                => 'date',
			'order'                  => 'ASC',
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
		) );

		$rows = array();
		foreach ( $query->posts as $post ) {
			$rows[] = array(
				'title'     => get_the_title( $post ),
				'edit'      => get_edit_post_link( $post, 'raw' ),
				'date'      => get_the_date( '', $post ),
				'time'      => get_the_time( '', $post ),
				'post_type' => $post->post_type,
			);
		}
		return $rows;
	}

	/* ================================================================
	 * Activity Feed — data
	 * ============================================================== */

	/**
	 * Merges the enabled, capability-permitted activity types into one
	 * chronological feed, cached for 5 minutes and invalidated whenever
	 * content, comments, registrations, or logins change (see
	 * invalidate_caches() / record_login()).
	 *
	 * @return array List of normalized entries, newest first.
	 */
	public function get_activity_feed() {
		$cached = get_transient( 'emmytech_pro_activity_feed' );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		$limit   = (int) $this->settings->get( 'activity_feed_limit', 8 );
		$catalog = self::activity_type_catalog();
		$types   = array_intersect( (array) $this->settings->get( 'activity_feed_types', array() ), array_keys( $catalog ) );

		$items = array();
		foreach ( $types as $type ) {
			if ( ! current_user_can( $catalog[ $type ]['capability'] ) ) {
				continue;
			}
			foreach ( call_user_func( $catalog[ $type ]['fetch'], $limit ) as $entry ) {
				$entry['type']  = $type;
				$entry['icon']  = $catalog[ $type ]['icon'];
				$entry['color'] = $catalog[ $type ]['color'];
				$items[]        = $entry;
			}
		}

		usort( $items, function ( $a, $b ) {
			return $b['timestamp'] <=> $a['timestamp'];
		} );
		$items = array_slice( $items, 0, max( 1, $limit ) );

		set_transient( 'emmytech_pro_activity_feed', $items, 5 * MINUTE_IN_SECONDS );
		return $items;
	}

	/**
	 * @param int $limit
	 * @return array Entries: title, meta, link, timestamp (no type/icon/color — added by get_activity_feed()).
	 */
	public static function fetch_activity_posts( $limit ) {
		$query = new WP_Query( array(
			'post_type'              => array( 'post', 'page' ),
			'post_status'            => 'publish',
			'posts_per_page'         => $limit,
			'orderby'                => 'date',
			'order'                  => 'DESC',
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
		) );

		$rows = array();
		foreach ( $query->posts as $post ) {
			$rows[] = array(
				'title'     => sprintf(
					/* translators: %s: post title. */
					__( 'Published: %s', 'emmytech-admin-pro' ),
					get_the_title( $post )
				),
				'meta'      => get_the_author_meta( 'display_name', $post->post_author ),
				'link'      => get_edit_post_link( $post, 'raw' ),
				'timestamp' => function_exists( 'get_post_timestamp' ) ? (int) get_post_timestamp( $post ) : (int) strtotime( $post->post_date ),
			);
		}
		return $rows;
	}

	public static function fetch_activity_comments( $limit ) {
		$query = new WP_Comment_Query( array(
			'status'  => 'approve',
			'number'  => $limit,
			'orderby' => 'comment_date',
			'order'   => 'DESC',
		) );

		$rows = array();
		foreach ( $query->get_comments() as $comment ) {
			$rows[] = array(
				'title'     => sprintf(
					/* translators: %s: commenter name. */
					__( '%s left a comment', 'emmytech-admin-pro' ),
					$comment->comment_author
				),
				'meta'      => wp_trim_words( $comment->comment_content, 12 ),
				'link'      => get_edit_comment_link( $comment->comment_ID ),
				'timestamp' => (int) strtotime( $comment->comment_date ),
			);
		}
		return $rows;
	}

	public static function fetch_activity_registrations( $limit ) {
		$query = new WP_User_Query( array(
			'orderby' => 'registered',
			'order'   => 'DESC',
			'number'  => $limit,
		) );

		$rows = array();
		foreach ( $query->get_results() as $user ) {
			$rows[] = array(
				'title'     => sprintf(
					/* translators: %s: user display name. */
					__( '%s joined the site', 'emmytech-admin-pro' ),
					$user->display_name
				),
				'meta'      => implode( ', ', array_map( 'ucfirst', (array) $user->roles ) ),
				'link'      => get_edit_user_link( $user->ID ),
				'timestamp' => (int) strtotime( $user->user_registered ),
			);
		}
		return $rows;
	}

	public static function fetch_activity_logins( $limit ) {
		$query = new WP_User_Query( array(
			'number'     => $limit,
			'orderby'    => 'meta_value_num',
			'order'      => 'DESC',
			'meta_key'   => '_emmytech_pro_last_login', // phpcs:ignore WordPress.DB.SlowDBQuery -- small, admin-only, capped by $limit.
			'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery
				array( 'key' => '_emmytech_pro_last_login', 'compare' => 'EXISTS' ),
			),
		) );

		$rows = array();
		foreach ( $query->get_results() as $user ) {
			$timestamp = (int) get_user_meta( $user->ID, '_emmytech_pro_last_login', true );
			if ( ! $timestamp ) {
				continue;
			}
			$rows[] = array(
				'title'     => sprintf(
					/* translators: %s: user display name. */
					__( '%s logged in', 'emmytech-admin-pro' ),
					$user->display_name
				),
				'meta'      => implode( ', ', array_map( 'ucfirst', (array) $user->roles ) ),
				'link'      => get_edit_user_link( $user->ID ),
				'timestamp' => $timestamp,
			);
		}
		return $rows;
	}

	/* ================================================================
	 * Widget rendering
	 * ============================================================== */

	public function render_hero_widget() {
		$user    = wp_get_current_user();
		$name    = $user->display_name ? $user->display_name : $user->user_login;
		$role    = ! empty( $user->roles[0] ) ? translate_user_role( ucfirst( $user->roles[0] ) ) : __( 'User', 'emmytech-admin-pro' );
		$pending = current_user_can( 'moderate_comments' ) ? (int) ( wp_count_comments()->moderated ?? 0 ) : 0;
		?>
		<div class="emmytech-hero">
			<div class="emmytech-hero-identity">
				<?php echo get_avatar( $user->ID, 48, '', '', array( 'class' => 'emmytech-avatar' ) ); ?>
				<div>
					<span class="emmytech-kicker"><?php echo esc_html( $role ); ?></span>
					<h2><?php printf( esc_html__( 'Welcome back, %s', 'emmytech-admin-pro' ), esc_html( $name ) ); ?></h2>
				</div>
			</div>
			<div class="emmytech-hero-actions">
				<?php if ( $pending > 0 ) : ?>
					<a class="emmytech-bell" href="<?php echo esc_url( admin_url( 'edit-comments.php?comment_status=moderated' ) ); ?>" title="<?php echo esc_attr( sprintf(
						/* translators: %d: number of pending comments. */
						_n( '%d comment awaiting moderation', '%d comments awaiting moderation', $pending, 'emmytech-admin-pro' ),
						$pending
					) ); ?>">
						<span class="dashicons dashicons-bell"></span>
						<span class="emmytech-bell-count"><?php echo esc_html( $pending ); ?></span>
					</a>
				<?php endif; ?>
				<a class="emmytech-btn emmytech-btn-light" href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'View Website', 'emmytech-admin-pro' ); ?></a>
			</div>
		</div>
		<?php
	}

	public function render_highlights_widget() {
		$cards = $this->get_highlights();
		?>
		<div class="emmytech-icon-cards">
			<?php foreach ( $cards as $card ) :
				if ( ! empty( $card['capability'] ) && ! current_user_can( $card['capability'] ) ) {
					continue;
				}
				?>
				<div class="emmytech-icon-card">
					<span class="emmytech-icon-square dashicons <?php echo esc_attr( $card['icon'] ); ?>" style="--card-color:<?php echo esc_attr( $card['color'] ); ?>"></span>
					<strong><?php echo esc_html( $card['today'] ); ?></strong>
					<span class="emmytech-icon-card-label"><?php echo esc_html( $card['label'] ); ?></span>
					<?php if ( null === $card['trend'] ) : ?>
						<span class="emmytech-trend is-up"><?php esc_html_e( 'New', 'emmytech-admin-pro' ); ?></span>
					<?php elseif ( $card['trend'] > 0 ) : ?>
						<span class="emmytech-trend is-up">+<?php echo esc_html( $card['trend'] ); ?>% <?php esc_html_e( 'vs yesterday', 'emmytech-admin-pro' ); ?></span>
					<?php elseif ( $card['trend'] < 0 ) : ?>
						<span class="emmytech-trend is-down"><?php echo esc_html( $card['trend'] ); ?>% <?php esc_html_e( 'vs yesterday', 'emmytech-admin-pro' ); ?></span>
					<?php else : ?>
						<span class="emmytech-trend"><?php esc_html_e( 'No change', 'emmytech-admin-pro' ); ?></span>
					<?php endif; ?>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
	}

	public function render_stats_widget() {
		$catalog  = self::stat_catalog();
		$selected = array_intersect( (array) $this->settings->get( 'dashboard_stats', array() ), array_keys( $catalog ) );

		if ( empty( $selected ) ) {
			echo '<p>' . esc_html__( 'No stat cards are selected. Choose some under EmmyTech → Dashboard.', 'emmytech-admin-pro' ) . '</p>';
			return;
		}
		?>
		<div class="emmytech-icon-cards">
			<?php foreach ( $selected as $key ) :
				$entry = $catalog[ $key ];
				$icon  = ! empty( $entry['icon'] ) ? $entry['icon'] : 'dashicons-chart-bar';
				$color = ! empty( $entry['color'] ) ? $entry['color'] : '#5b8def';
				?>
				<div class="emmytech-icon-card">
					<span class="emmytech-icon-square dashicons <?php echo esc_attr( $icon ); ?>" style="--card-color:<?php echo esc_attr( $color ); ?>"></span>
					<strong><?php echo esc_html( call_user_func( $entry['value'] ) ); ?></strong>
					<span class="emmytech-icon-card-label"><?php echo esc_html( $entry['label'] ); ?></span>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
		$this->maybe_render_comment_alert();
	}

	private function maybe_render_comment_alert() {
		if ( ! current_user_can( 'moderate_comments' ) ) {
			return;
		}
		$counts  = wp_count_comments();
		$pending = isset( $counts->moderated ) ? (int) $counts->moderated : 0;
		if ( $pending <= 0 ) {
			return;
		}
		?>
		<div class="emmytech-alert">
			<?php
			printf(
				/* translators: %d: number of pending comments. */
				esc_html( _n( 'You have %d comment awaiting moderation.', 'You have %d comments awaiting moderation.', $pending, 'emmytech-admin-pro' ) ),
				$pending
			);
			?>
			<a href="<?php echo esc_url( admin_url( 'edit-comments.php?comment_status=moderated' ) ); ?>"><?php esc_html_e( 'Review now', 'emmytech-admin-pro' ); ?></a>
		</div>
		<?php
	}

	public function render_weekly_activity_widget() {
		$data = $this->get_weekly_activity();
		$this->render_chart_canvas( 'weekly-activity', 'bar', $data['labels'], array(
			array( 'label' => __( 'Posts Published', 'emmytech-admin-pro' ), 'data' => $data['data'] ),
		) );
	}

	public function render_content_mix_widget() {
		$mix = $this->get_content_mix();
		$this->render_chart_canvas( 'content-mix', 'doughnut', $mix['labels'], array(
			array( 'data' => $mix['data'], 'colors' => array( '#5b8def', '#17c3b2', '#9b59b6' ) ),
		), array( 'centerText' => $mix['percent'] . '%' ) );
	}

	public function render_content_growth_widget() {
		$data = $this->get_content_growth();
		$this->render_chart_canvas( 'content-growth', 'line', $data['labels'], array(
			array( 'label' => __( 'Posts Published', 'emmytech-admin-pro' ), 'data' => $data['data'] ),
		) );
	}

	/**
	 * Shared chart markup: a canvas plus a JSON <script> payload that
	 * assets/js/admin-charts.js reads on DOMContentLoaded. Keeping chart
	 * construction in one JS file (rather than inline per-widget script
	 * tags) means every widget gets identical theming for free and there
	 * is exactly one place that touches the Chart.js API.
	 *
	 * @param string $slug     Unique per-widget identifier.
	 * @param string $type     'bar' | 'doughnut' | 'line'.
	 * @param array  $labels
	 * @param array  $datasets
	 * @param array  $extra    Optional extra payload (e.g. centerText).
	 */
	private function render_chart_canvas( $slug, $type, array $labels, array $datasets, array $extra = array() ) {
		$payload = array_merge( array(
			'type'     => $type,
			'labels'   => array_values( $labels ),
			'datasets' => array_values( $datasets ),
		), $extra );
		?>
		<div class="emmytech-chart-wrap">
			<canvas id="emmytech-chart-<?php echo esc_attr( $slug ); ?>" height="220"></canvas>
			<script type="application/json" class="emmytech-chart-data" data-target="emmytech-chart-<?php echo esc_attr( $slug ); ?>">
				<?php echo wp_json_encode( $payload ); ?>
			</script>
		</div>
		<?php
	}

	public function render_top_content_widget() {
		$rows = $this->get_top_content();

		if ( empty( $rows ) ) {
			echo '<p>' . esc_html__( 'No published posts with comments yet.', 'emmytech-admin-pro' ) . '</p>';
			return;
		}
		?>
		<table class="emmytech-top-content">
			<?php foreach ( $rows as $row ) : ?>
				<tr>
					<td class="emmytech-top-content-title">
						<?php if ( $row['edit'] ) : ?>
							<a href="<?php echo esc_url( $row['edit'] ); ?>"><?php echo esc_html( $row['title'] ); ?></a>
						<?php else : ?>
							<?php echo esc_html( $row['title'] ); ?>
						<?php endif; ?>
						<div class="emmytech-progress"><span style="width:<?php echo esc_attr( $row['percent'] ); ?>%"></span></div>
					</td>
					<td class="emmytech-top-content-badge"><span class="emmytech-badge"><?php echo esc_html( $row['count'] ); ?></span></td>
				</tr>
			<?php endforeach; ?>
		</table>
		<?php
	}

	public function render_schedule_widget() {
		$rows = $this->get_upcoming_schedule();

		if ( empty( $rows ) ) {
			echo '<p>' . esc_html__( 'Nothing scheduled. Posts and pages set to publish in the future will appear here.', 'emmytech-admin-pro' ) . '</p>';
			return;
		}

		$colors = array( 'post' => 'is-blue', 'page' => 'is-teal' );
		?>
		<ul class="emmytech-schedule">
			<?php foreach ( $rows as $row ) :
				$color_class = $colors[ $row['post_type'] ] ?? 'is-amber';
				?>
				<li class="emmytech-schedule-item <?php echo esc_attr( $color_class ); ?>">
					<span class="emmytech-schedule-icon dashicons dashicons-calendar-alt"></span>
					<div>
						<strong><?php echo $row['edit'] ? '<a href="' . esc_url( $row['edit'] ) . '">' . esc_html( $row['title'] ) . '</a>' : esc_html( $row['title'] ); ?></strong>
						<span><?php echo esc_html( $row['date'] . ' · ' . $row['time'] ); ?></span>
					</div>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php
	}

	/**
	 * Renders the Activity Feed: a merged, chronological timeline of
	 * recent posts, comments, registrations, and logins. Each entry's
	 * timestamp is a "live" element (assets/js/activity-timer.js
	 * recomputes the relative time client-side every 30 seconds, so the
	 * feed keeps ticking — "5 minutes ago" becomes "6 minutes ago" —
	 * without a page reload).
	 */
	public function render_activity_widget() {
		$items = $this->get_activity_feed();

		if ( empty( $items ) ) {
			echo '<p>' . esc_html__( 'No recent activity yet.', 'emmytech-admin-pro' ) . '</p>';
			return;
		}
		?>
		<ul class="emmytech-activity-feed">
			<?php foreach ( $items as $item ) :
				$now_relative = human_time_diff( $item['timestamp'], current_time( 'timestamp' ) );
				?>
				<li class="emmytech-activity-item">
					<span class="emmytech-activity-icon dashicons <?php echo esc_attr( $item['icon'] ); ?>" style="--card-color:<?php echo esc_attr( $item['color'] ); ?>"></span>
					<div class="emmytech-activity-body">
						<?php if ( ! empty( $item['link'] ) ) : ?>
							<a href="<?php echo esc_url( $item['link'] ); ?>"><?php echo esc_html( $item['title'] ); ?></a>
						<?php else : ?>
							<strong><?php echo esc_html( $item['title'] ); ?></strong>
						<?php endif; ?>
						<?php if ( ! empty( $item['meta'] ) ) : ?>
							<span class="emmytech-activity-meta"><?php echo esc_html( $item['meta'] ); ?></span>
						<?php endif; ?>
					</div>
					<time class="emmytech-live-time" data-timestamp="<?php echo esc_attr( $item['timestamp'] ); ?>" data-ago="<?php echo esc_attr__( 'ago', 'emmytech-admin-pro' ); ?>">
						<?php
						printf(
							/* translators: %s: human-readable time difference, e.g. "5 minutes". */
							esc_html__( '%s ago', 'emmytech-admin-pro' ),
							esc_html( $now_relative )
						);
						?>
					</time>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php
	}

	public function render_quick_actions_widget() {
		$catalog  = self::quick_action_catalog();
		$selected = array_intersect( (array) $this->settings->get( 'quick_actions', array() ), array_keys( $catalog ) );

		$visible = array();
		foreach ( $selected as $key ) {
			$action = $catalog[ $key ];
			if ( current_user_can( $action['capability'] ) ) {
				$visible[ $key ] = $action;
			}
		}

		if ( empty( $visible ) ) {
			echo '<p>' . esc_html__( 'No quick actions are available for your account.', 'emmytech-admin-pro' ) . '</p>';
			return;
		}
		?>
		<div class="emmytech-actions">
			<?php foreach ( $visible as $action ) : ?>
				<a href="<?php echo esc_url( call_user_func( $action['url'] ) ); ?>">
					<?php if ( ! empty( $action['icon'] ) ) : ?><span class="dashicons <?php echo esc_attr( $action['icon'] ); ?>"></span><?php endif; ?>
					<?php echo esc_html( $action['label'] ); ?>
				</a>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * Server Information widget. Everything here comes from documented
	 * WordPress/PHP APIs — $wpdb->db_version() rather than a raw SQL
	 * version query, ini_get()/extension_loaded() for the PHP runtime,
	 * and $_SERVER only for read-only, escaped-on-output display values.
	 */
	public function render_system_info_widget() {
		global $wp_version, $wpdb;

		$theme          = wp_get_theme();
		$https          = is_ssl() ? __( 'Enabled', 'emmytech-admin-pro' ) : __( 'Not detected', 'emmytech-admin-pro' );
		$memory_limit   = ini_get( 'memory_limit' );
		$max_upload     = size_format( wp_max_upload_size() );
		$max_execution  = ini_get( 'max_execution_time' );
		$server_software = isset( $_SERVER['SERVER_SOFTWARE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) ) : __( 'Unknown', 'emmytech-admin-pro' );
		$db_version     = ( $wpdb && method_exists( $wpdb, 'db_version' ) ) ? $wpdb->db_version() : __( 'Unknown', 'emmytech-admin-pro' );
		$timezone       = wp_timezone_string();
		$debug_mode     = ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ? __( 'Enabled', 'emmytech-admin-pro' ) : __( 'Disabled', 'emmytech-admin-pro' );

		$extensions = array_filter( array(
			'cURL'      => extension_loaded( 'curl' ),
			'GD'        => extension_loaded( 'gd' ),
			'Imagick'   => extension_loaded( 'imagick' ),
			'mbstring'  => extension_loaded( 'mbstring' ),
			'OpenSSL'   => extension_loaded( 'openssl' ),
		) );
		?>
		<?php if ( '1' === $this->settings->get( 'server_info_show_clock', '1' ) ) : ?>
			<div class="emmytech-server-clock" id="emmytech-server-clock" data-timestamp="<?php echo esc_attr( current_time( 'timestamp' ) ); ?>">
				<span class="emmytech-clock-label"><?php esc_html_e( 'Server Time', 'emmytech-admin-pro' ); ?></span>
				<span class="emmytech-clock-value" id="emmytech-clock-value"><?php echo esc_html( current_time( 'H:i:s' ) ); ?></span>
				<span class="emmytech-clock-date"><?php echo esc_html( date_i18n( get_option( 'date_format' ) ) ); ?></span>
			</div>
		<?php endif; ?>
		<ul class="emmytech-system-info">
			<li><span><?php esc_html_e( 'WordPress', 'emmytech-admin-pro' ); ?></span><strong><?php echo esc_html( $wp_version ); ?></strong></li>
			<li><span><?php esc_html_e( 'PHP', 'emmytech-admin-pro' ); ?></span><strong><?php echo esc_html( phpversion() ); ?></strong></li>
			<li><span><?php esc_html_e( 'Database', 'emmytech-admin-pro' ); ?></span><strong><?php echo esc_html( $db_version ); ?></strong></li>
			<li><span><?php esc_html_e( 'Server Software', 'emmytech-admin-pro' ); ?></span><strong><?php echo esc_html( $server_software ); ?></strong></li>
			<li><span><?php esc_html_e( 'Active Theme', 'emmytech-admin-pro' ); ?></span><strong><?php echo esc_html( $theme->get( 'Name' ) ); ?></strong></li>
			<li><span><?php esc_html_e( 'Timezone', 'emmytech-admin-pro' ); ?></span><strong><?php echo esc_html( $timezone ? $timezone : 'UTC' ); ?></strong></li>
			<li><span><?php esc_html_e( 'HTTPS', 'emmytech-admin-pro' ); ?></span><strong><?php echo esc_html( $https ); ?></strong></li>
			<li><span><?php esc_html_e( 'Debug Mode', 'emmytech-admin-pro' ); ?></span><strong><?php echo esc_html( $debug_mode ); ?></strong></li>
			<li><span><?php esc_html_e( 'PHP Memory Limit', 'emmytech-admin-pro' ); ?></span><strong><?php echo esc_html( $memory_limit ); ?></strong></li>
			<li><span><?php esc_html_e( 'Max Execution Time', 'emmytech-admin-pro' ); ?></span><strong><?php echo esc_html( $max_execution ); ?>s</strong></li>
			<li><span><?php esc_html_e( 'Max Upload Size', 'emmytech-admin-pro' ); ?></span><strong><?php echo esc_html( $max_upload ); ?></strong></li>
			<?php if ( ! empty( $extensions ) ) : ?>
				<li><span><?php esc_html_e( 'PHP Extensions', 'emmytech-admin-pro' ); ?></span><strong><?php echo esc_html( implode( ', ', array_keys( $extensions ) ) ); ?></strong></li>
			<?php endif; ?>
		</ul>
		<p class="emmytech-env"><?php esc_html_e( 'Copy this information when contacting support.', 'emmytech-admin-pro' ); ?></p>
		<?php
	}
}
