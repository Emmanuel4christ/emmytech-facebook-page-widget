<?php
/**
 * Admin asset module for EmmyTech Admin Pro.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EmmyTech_Assets {

	/** @var EmmyTech_Settings */
	private $settings;

	public function __construct( EmmyTech_Settings $settings ) {
		$this->settings = $settings;

		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
		add_filter( 'admin_body_class', array( $this, 'body_class' ) );
	}

	public function enqueue( $hook ) {
		wp_enqueue_style( 'dashicons' );
		wp_enqueue_style( 'emmytech-pro-admin', EMMYTECH_PRO_URL . 'assets/css/admin.css', array(), EMMYTECH_PRO_VERSION );
		wp_enqueue_script( 'emmytech-pro-admin', EMMYTECH_PRO_URL . 'assets/js/admin.js', array(), EMMYTECH_PRO_VERSION, true );

		$accent = $this->settings->get( 'accent_color', '#5b8def' );
		$accent = sanitize_hex_color( $accent );
		wp_add_inline_style( 'emmytech-pro-admin', ':root{--emmy-accent:' . ( $accent ? $accent : '#5b8def' ) . ';}' );

		// The live-preview script only belongs on our own Appearance page.
		// The hook suffix WordPress computes for a submenu depends on the
		// top-level menu's (translatable) title, so match on the stable
		// page slug at the end of the suffix rather than hardcoding it.
		if ( is_string( $hook ) && false !== strpos( $hook, 'emmytech-admin-appearance' ) ) {
			wp_enqueue_script( 'wp-color-picker' );
			wp_enqueue_style( 'wp-color-picker' );
			wp_enqueue_script( 'emmytech-pro-appearance', EMMYTECH_PRO_URL . 'assets/js/appearance.js', array( 'jquery', 'wp-color-picker' ), EMMYTECH_PRO_VERSION, true );
		}

		// The WordPress Dashboard screen ('index.php') is the only place
		// our chart widgets render, so Chart.js only loads there.
		if ( 'index.php' === $hook ) {
			wp_enqueue_script( 'emmytech-pro-chartjs', EMMYTECH_PRO_URL . 'assets/js/vendor/chart.umd.min.js', array(), '4.5.1', true );
			wp_enqueue_script( 'emmytech-pro-admin-charts', EMMYTECH_PRO_URL . 'assets/js/admin-charts.js', array( 'emmytech-pro-chartjs' ), EMMYTECH_PRO_VERSION, true );

			// Live-ticking Activity Feed timestamps and the Server
			// Information clock — independent of chart.js, and needed in
			// both the "At a glance" and classic dashboard layouts.
			wp_enqueue_script( 'emmytech-pro-activity-timer', EMMYTECH_PRO_URL . 'assets/js/activity-timer.js', array(), EMMYTECH_PRO_VERSION, true );

			// The full-width "At a glance" layout: its own stylesheet and a
			// tiny script, loaded only on the Dashboard and only in that mode.
			if ( $this->is_glance_layout() ) {
				wp_enqueue_style( 'emmytech-pro-dashboard-glance', EMMYTECH_PRO_URL . 'assets/css/dashboard-glance.css', array( 'emmytech-pro-admin' ), EMMYTECH_PRO_VERSION );
				wp_enqueue_script( 'emmytech-pro-dashboard-glance', EMMYTECH_PRO_URL . 'assets/js/dashboard-glance.js', array( 'jquery' ), EMMYTECH_PRO_VERSION, true );
			}
		}

		// The sortable dashboard-customization checklists only belong on
		// our own Dashboard settings page.
		if ( is_string( $hook ) && false !== strpos( $hook, 'emmytech-dashboard-settings' ) ) {
			wp_enqueue_script( 'jquery-ui-sortable' );
			wp_enqueue_script( 'emmytech-pro-dashboard-settings', EMMYTECH_PRO_URL . 'assets/js/dashboard-settings.js', array( 'jquery', 'jquery-ui-sortable' ), EMMYTECH_PRO_VERSION, true );
		}

		// Small confirmation prompt for the "Reset to Defaults" button.
		if ( is_string( $hook ) && false !== strpos( $hook, 'emmytech-tools' ) ) {
			wp_enqueue_script( 'emmytech-pro-tools', EMMYTECH_PRO_URL . 'assets/js/tools.js', array( 'jquery' ), EMMYTECH_PRO_VERSION, true );
			wp_localize_script( 'emmytech-pro-tools', 'EmmyTechTools', array(
				'confirmReset' => __( 'This will restore every EmmyTech Admin Pro setting to its default value. Continue?', 'emmytech-admin-pro' ),
			) );
		}
	}

	/**
	 * True when the "At a glance" dashboard layout applies to the current
	 * user. Users who can't see the EmmyTech widgets keep the stock layout.
	 *
	 * @return bool
	 */
	private function is_glance_layout() {
		return 'glance' === $this->settings->get( 'dashboard_layout', 'glance' ) && current_user_can( 'edit_posts' );
	}

	public function body_class( $classes ) {
		$classes .= ' emmytech-pro-admin';
		$classes .= '1' === $this->settings->get( 'dark_admin_nav', '1' ) ? ' emmytech-pro-dark-nav' : ' emmytech-pro-light-nav';

		// Layout hooks for the Dashboard screen only ('dashboard' is the
		// screen ID of wp-admin/index.php; the network and user dashboards
		// use different IDs and are left alone).
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen && 'dashboard' === $screen->id && $this->is_glance_layout() ) {
			$classes .= ' emmytech-glance';
			if ( '1' === $this->settings->get( 'replace_dashboard', '1' ) ) {
				// Also hides core's "Welcome to WordPress" panel.
				$classes .= ' emmytech-glance-clean';
			}
		}

		return $classes;
	}
}
