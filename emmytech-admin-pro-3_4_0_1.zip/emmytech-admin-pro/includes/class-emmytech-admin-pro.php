<?php
/**
 * Core bootstrap for EmmyTech Admin Pro.
 *
 * This class is intentionally thin: it loads each module file, wires the
 * modules together (each module receives only the collaborators it needs
 * via its constructor), and exposes the shared settings object. All actual
 * behavior lives in the module classes it constructs, which keeps any one
 * file small enough to read, test, and extend independently.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EmmyTech_Admin_Pro {

	/** @var EmmyTech_Admin_Pro|null */
	private static $instance = null;

	/** @var EmmyTech_Settings */
	private $settings;

	/** @return EmmyTech_Admin_Pro */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/** @return array Convenience passthrough used by the activation hook. */
	public static function default_settings() {
		return EmmyTech_Settings::defaults();
	}

	private function __construct() {
		$this->load_modules();

		$this->settings = new EmmyTech_Settings();
		$this->settings->migrate();

		new EmmyTech_Login( $this->settings );
		new EmmyTech_Assets( $this->settings );
		new EmmyTech_Footer( $this->settings );
		new EmmyTech_Dashboard( $this->settings );

		$pages = new EmmyTech_Admin_Pages( $this->settings );
		new EmmyTech_Menu( $this->settings, $pages );
	}

	private function load_modules() {
		$path = EMMYTECH_PRO_PATH . 'includes/';
		require_once $path . 'class-emmytech-settings.php';
		require_once $path . 'class-emmytech-dashboard.php';
		require_once $path . 'class-emmytech-login.php';
		require_once $path . 'class-emmytech-assets.php';
		require_once $path . 'class-emmytech-footer.php';
		require_once $path . 'class-emmytech-admin-pages.php';
		require_once $path . 'class-emmytech-menu.php';
	}

	/** @return EmmyTech_Settings */
	public function settings() {
		return $this->settings;
	}
}
