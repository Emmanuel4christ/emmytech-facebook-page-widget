<?php
/**
 * Admin menu module for EmmyTech Admin Pro.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EmmyTech_Menu {

	/** @var EmmyTech_Settings */
	private $settings;

	/** @var EmmyTech_Admin_Pages */
	private $pages;

	public function __construct( EmmyTech_Settings $settings, EmmyTech_Admin_Pages $pages ) {
		$this->settings = $settings;
		$this->pages    = $pages;

		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_menu', array( $this, 'hide_configured_menu_items' ), 999 );
		add_action( 'admin_bar_menu', array( $this, 'admin_bar_branding' ), 999 );
		add_filter( 'plugin_action_links_' . EMMYTECH_PRO_BASENAME, array( $this, 'plugin_action_links' ) );
	}

	public function register_menu() {
		$cap = EmmyTech_Settings::capability();
		if ( ! current_user_can( $cap ) ) {
			return;
		}

		$icon = $this->settings->get( 'menu_icon', 'dashicons-admin-customizer' );

		add_menu_page(
			__( 'EmmyTech Control Center', 'emmytech-admin-pro' ),
			__( 'EmmyTech', 'emmytech-admin-pro' ),
			$cap,
			'emmytech-control-center',
			array( $this->pages, 'render_control_center_page' ),
			$icon,
			2
		);

		add_submenu_page( 'emmytech-control-center', __( 'Control Center', 'emmytech-admin-pro' ), __( 'Control Center', 'emmytech-admin-pro' ), $cap, 'emmytech-control-center', array( $this->pages, 'render_control_center_page' ) );
		add_submenu_page( 'emmytech-control-center', __( 'Admin Appearance', 'emmytech-admin-pro' ), __( 'Appearance', 'emmytech-admin-pro' ), $cap, 'emmytech-admin-appearance', array( $this->pages, 'render_appearance_page' ) );
		add_submenu_page( 'emmytech-control-center', __( 'Dashboard Settings', 'emmytech-admin-pro' ), __( 'Dashboard', 'emmytech-admin-pro' ), $cap, 'emmytech-dashboard-settings', array( $this->pages, 'render_dashboard_page' ) );
		add_submenu_page( 'emmytech-control-center', __( 'Tools', 'emmytech-admin-pro' ), __( 'Tools', 'emmytech-admin-pro' ), $cap, 'emmytech-tools', array( $this->pages, 'render_tools_page' ) );
		add_submenu_page( 'emmytech-control-center', __( 'About', 'emmytech-admin-pro' ), __( 'About', 'emmytech-admin-pro' ), $cap, 'emmytech-about', array( $this->pages, 'render_about_page' ) );
	}

	/**
	 * Hides configured top-level menu slugs for everyone (including the
	 * current user, capability permitting) to declutter wp-admin. This
	 * only hides the menu item — it never changes capabilities, so a
	 * direct URL still works and nobody can be locked out by this alone.
	 */
	public function hide_configured_menu_items() {
		$slugs = (array) $this->settings->get( 'hidden_menu_slugs', array() );
		foreach ( $slugs as $slug ) {
			remove_menu_page( $slug );
		}
	}

	public function plugin_action_links( $links ) {
		$settings_link = '<a href="' . esc_url( admin_url( 'admin.php?page=emmytech-control-center' ) ) . '">' . esc_html__( 'Settings', 'emmytech-admin-pro' ) . '</a>';
		array_unshift( $links, $settings_link );
		return $links;
	}

	public function admin_bar_branding( $wp_admin_bar ) {
		if ( '1' !== $this->settings->get( 'admin_bar_branding', '1' ) ) {
			return;
		}
		if ( ! current_user_can( EmmyTech_Settings::capability() ) ) {
			return;
		}

		$wp_admin_bar->add_node( array(
			'id'    => 'emmytech-brand',
			'title' => '<span class="ab-icon dashicons dashicons-admin-customizer"></span><span class="emmytech-adminbar-brand">EmmyTech</span>',
			'href'  => admin_url( 'admin.php?page=emmytech-control-center' ),
			'meta'  => array( 'title' => __( 'EmmyTech Control Center', 'emmytech-admin-pro' ) ),
		) );

		$wp_admin_bar->add_node( array(
			'id'     => 'emmytech-brand-appearance',
			'parent' => 'emmytech-brand',
			'title'  => __( 'Admin Appearance', 'emmytech-admin-pro' ),
			'href'   => admin_url( 'admin.php?page=emmytech-admin-appearance' ),
		) );

		$wp_admin_bar->add_node( array(
			'id'     => 'emmytech-brand-dashboard',
			'parent' => 'emmytech-brand',
			'title'  => __( 'Dashboard Settings', 'emmytech-admin-pro' ),
			'href'   => admin_url( 'admin.php?page=emmytech-dashboard-settings' ),
		) );

		if ( current_user_can( 'edit_posts' ) ) {
			$wp_admin_bar->add_node( array(
				'id'     => 'emmytech-brand-newpost',
				'parent' => 'emmytech-brand',
				'title'  => __( 'New Post', 'emmytech-admin-pro' ),
				'href'   => admin_url( 'post-new.php' ),
			) );
		}
	}
}
