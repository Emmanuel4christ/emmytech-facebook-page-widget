<?php
/**
 * Settings module for EmmyTech Admin Pro.
 *
 * Single source of truth for plugin data. Every other class reads
 * configuration through this object instead of calling get_option()
 * directly, so there is exactly one place that knows the option name,
 * the default values, and how each field is sanitized.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EmmyTech_Settings {

	/** @var array|null Cached settings for the current request. */
	private $cache = null;

	/**
	 * Capability required to manage the plugin. Filterable so a site
	 * owner can loosen or tighten it (e.g. a custom "emmytech_manage"
	 * capability) without editing plugin code.
	 *
	 * @return string
	 */
	public static function capability() {
		return apply_filters( 'emmytech_pro_capability', 'manage_options' );
	}

	/**
	 * @return array Full default settings, used on activation and as a
	 *               safe merge base so upgrades never produce undefined
	 *               index notices.
	 */
	public static function defaults() {
		return array(
			// Branding.
			'logo_url'                      => '',
			'logo_width'                     => 190,
			'accent_color'                   => '#5b8def',
			'login_bg_color'                 => '#0b0d10',
			'menu_icon'                      => 'dashicons-admin-customizer',

			// Interface.
			'dark_admin_nav'                 => '1',
			'admin_bar_branding'             => '1',

			// Footer.
			'custom_footer_text'             => 'Powered by <strong>EmmyTech Software Solution</strong> · We Innovate. Build and Scale.',
			'hide_footer_version'            => '1',

			// Dashboard — which widgets appear at all.
			'dashboard_widget_hero'          => '1',
			'dashboard_widget_highlights'    => '1',
			'dashboard_widget_stats'         => '1',
			'dashboard_widget_weekly_activity' => '1',
			'dashboard_widget_content_mix'   => '1',
			'dashboard_widget_content_growth' => '1',
			'dashboard_widget_top_content'   => '1',
			'dashboard_widget_schedule'      => '1',
			'dashboard_widget_activity'      => '1',
			'dashboard_widget_quick_actions' => '1',
			'dashboard_widget_system_info'   => '1',
			'replace_dashboard'              => '1',

			// Dashboard layout. 'glance' = every widget on one full-width,
			// responsive grid (no dead columns, no drag-reordering).
			// 'classic' = WordPress's native draggable two-column layout.
			'dashboard_layout'               => 'glance',

			// Dashboard — customizable, ordered content. Only keys present
			// in the array are shown, in the order given.
			'dashboard_stats'                => array( 'posts_published', 'pages_published', 'total_users', 'posts_draft', 'comments_approved', 'media_count' ),
			'quick_actions'                  => array( 'new_post', 'new_page', 'media', 'users', 'plugins', 'settings', 'profile' ),
			'activity_feed_types'            => array( 'posts', 'comments', 'users_registered', 'users_login' ),
			'activity_feed_limit'            => 8,

			// Server Information widget.
			'server_info_show_clock'         => '1',

			// Advanced / Tools.
			'hidden_menu_slugs'              => array(),
			'login_redirect_url'             => '',
			'login_redirect_admins'          => '0',
		);
	}

	/**
	 * @return array Current settings merged over defaults.
	 */
	public function all() {
		if ( null === $this->cache ) {
			$saved       = get_option( EMMYTECH_PRO_OPTION, array() );
			$saved       = is_array( $saved ) ? $saved : array();
			$this->cache = array_merge( self::defaults(), $saved );
		}
		return $this->cache;
	}

	/**
	 * @param string $key
	 * @param mixed  $fallback
	 * @return mixed
	 */
	public function get( $key, $fallback = '' ) {
		$all = $this->all();
		return array_key_exists( $key, $all ) ? $all[ $key ] : $fallback;
	}

	/**
	 * Persists a full settings array (already sanitized by the caller)
	 * merged over whatever is currently stored, and resets the cache.
	 *
	 * @param array $updated
	 */
	public function save( array $updated ) {
		$current = $this->all();
		update_option( EMMYTECH_PRO_OPTION, array_merge( $current, $updated ) );
		$this->cache = null;
	}

	/**
	 * Restores every setting to its default value.
	 */
	public function reset_to_defaults() {
		update_option( EMMYTECH_PRO_OPTION, self::defaults() );
		$this->cache = null;
	}

	/**
	 * Serializes current settings to a pretty-printed JSON string for
	 * download from the Tools page.
	 *
	 * @return string
	 */
	public function export_json() {
		$payload = array(
			'plugin'    => 'emmytech-admin-pro',
			'version'   => EMMYTECH_PRO_VERSION,
			'exported'  => gmdate( 'c' ),
			'settings'  => $this->all(),
		);
		return wp_json_encode( $payload, JSON_PRETTY_PRINT );
	}

	/**
	 * Imports settings from a JSON string produced by export_json().
	 * Every field is re-sanitized with the same rules used for normal
	 * form submissions — an imported file is treated as untrusted input,
	 * never as pre-validated data.
	 *
	 * @param string $json Raw file contents.
	 * @return true|WP_Error
	 */
	public function import_json( $json ) {
		$decoded = json_decode( (string) $json, true );

		if ( ! is_array( $decoded ) || empty( $decoded['settings'] ) || ! is_array( $decoded['settings'] ) ) {
			return new WP_Error( 'emmytech_invalid_file', __( 'That file does not look like a valid EmmyTech Admin Pro settings export.', 'emmytech-admin-pro' ) );
		}

		$incoming = $decoded['settings'];
		$defaults = self::defaults();
		$clean    = array();

		$clean['logo_url']              = isset( $incoming['logo_url'] ) ? esc_url_raw( $incoming['logo_url'] ) : $defaults['logo_url'];
		$clean['logo_width']            = self::sanitize_int_range( $incoming['logo_width'] ?? null, 40, 600, $defaults['logo_width'] );
		$clean['accent_color']          = self::sanitize_hex( $incoming['accent_color'] ?? null, $defaults['accent_color'] );
		$clean['login_bg_color']        = self::sanitize_hex( $incoming['login_bg_color'] ?? null, $defaults['login_bg_color'] );
		$clean['menu_icon']             = ! empty( $incoming['menu_icon'] ) ? sanitize_text_field( $incoming['menu_icon'] ) : $defaults['menu_icon'];

		foreach ( array( 'dark_admin_nav', 'admin_bar_branding', 'hide_footer_version', 'dashboard_widget_hero', 'dashboard_widget_highlights', 'dashboard_widget_stats', 'dashboard_widget_weekly_activity', 'dashboard_widget_content_mix', 'dashboard_widget_content_growth', 'dashboard_widget_top_content', 'dashboard_widget_schedule', 'dashboard_widget_activity', 'dashboard_widget_quick_actions', 'dashboard_widget_system_info', 'replace_dashboard', 'login_redirect_admins', 'server_info_show_clock' ) as $bool_key ) {
			$clean[ $bool_key ] = self::sanitize_bool( $incoming[ $bool_key ] ?? null, $defaults[ $bool_key ] );
		}

		$clean['dashboard_layout'] = self::sanitize_layout( $incoming['dashboard_layout'] ?? null, $defaults['dashboard_layout'] );

		$clean['custom_footer_text'] = isset( $incoming['custom_footer_text'] ) ? wp_kses_post( $incoming['custom_footer_text'] ) : $defaults['custom_footer_text'];

		$clean['dashboard_stats']     = self::sanitize_key_list( $incoming['dashboard_stats'] ?? array(), array_keys( EmmyTech_Dashboard::stat_catalog() ) );
		$clean['quick_actions']       = self::sanitize_key_list( $incoming['quick_actions'] ?? array(), array_keys( EmmyTech_Dashboard::quick_action_catalog() ) );
		$clean['activity_feed_types'] = self::sanitize_key_list( $incoming['activity_feed_types'] ?? array(), array_keys( EmmyTech_Dashboard::activity_type_catalog() ) );
		$clean['activity_feed_limit'] = self::sanitize_int_range( $incoming['activity_feed_limit'] ?? null, 3, 20, $defaults['activity_feed_limit'] );

		$clean['hidden_menu_slugs'] = self::sanitize_slug_list( $incoming['hidden_menu_slugs'] ?? array() );
		$clean['login_redirect_url'] = isset( $incoming['login_redirect_url'] ) ? esc_url_raw( $incoming['login_redirect_url'] ) : '';

		update_option( EMMYTECH_PRO_OPTION, array_merge( $defaults, $clean ) );
		$this->cache = null;

		return true;
	}

	/* --------------------------------------------------------------
	 * Reusable field sanitizers (shared by the form handler and the
	 * JSON importer so both paths enforce identical rules).
	 * ------------------------------------------------------------ */

	public static function sanitize_int_range( $value, $min, $max, $default ) {
		$value = absint( $value );
		if ( $value < $min || $value > $max ) {
			return $default;
		}
		return $value;
	}

	public static function sanitize_hex( $value, $default ) {
		$hex = is_string( $value ) ? sanitize_hex_color( $value ) : '';
		return $hex ? $hex : $default;
	}

	/**
	 * Whitelists the dashboard layout mode.
	 *
	 * @param mixed  $value
	 * @param string $default
	 * @return string 'glance' or 'classic'.
	 */
	public static function sanitize_layout( $value, $default = 'glance' ) {
		return ( is_string( $value ) && in_array( $value, array( 'glance', 'classic' ), true ) ) ? $value : $default;
	}

	public static function sanitize_bool( $value, $default = '0' ) {
		if ( null === $value ) {
			return $default;
		}
		return ! empty( $value ) && '0' !== $value ? '1' : '0';
	}

	/**
	 * Intersects a submitted list of keys against a whitelist, preserving
	 * the submitted order. Used for both dashboard stats and quick
	 * actions so users can pick which items show and in what order.
	 *
	 * @param mixed $submitted
	 * @param array $whitelist
	 * @return array
	 */
	public static function sanitize_key_list( $submitted, array $whitelist ) {
		if ( ! is_array( $submitted ) ) {
			return array();
		}
		$clean = array();
		foreach ( $submitted as $key ) {
			if ( ! is_scalar( $key ) ) {
				continue;
			}
			$key = sanitize_key( $key );
			if ( in_array( $key, $whitelist, true ) && ! in_array( $key, $clean, true ) ) {
				$clean[] = $key;
			}
		}
		return $clean;
	}

	/**
	 * Sanitizes a list of admin menu slugs, refusing to let the Dashboard
	 * or the plugin's own menu be hidden (that would either lock users
	 * out of wp-admin's home screen or hide the only way back into these
	 * settings).
	 *
	 * @param mixed $submitted Array of slugs, or newline/comma separated string.
	 * @return array
	 */
	public static function sanitize_slug_list( $submitted ) {
		if ( is_string( $submitted ) ) {
			$submitted = preg_split( '/[\r\n,]+/', $submitted );
		}
		if ( ! is_array( $submitted ) ) {
			return array();
		}

		$protected = array( 'index.php', 'emmytech-control-center' );
		$clean     = array();

		foreach ( $submitted as $slug ) {
			if ( ! is_scalar( $slug ) ) {
				continue;
			}
			$slug = sanitize_text_field( trim( (string) $slug ) );
			if ( '' === $slug || in_array( $slug, $protected, true ) || in_array( $slug, $clean, true ) ) {
				continue;
			}
			$clean[] = $slug;
		}

		return $clean;
	}

	/**
	 * Migrates settings forward across plugin versions. Safe to call on
	 * every load; each step checks its own "already ran" flag.
	 */
	public function migrate() {
		$this->migrate_from_v2();
		$this->migrate_from_v30();
	}

	/**
	 * Pre-3.0 releases stored logo_url / accent / dark_mode as three
	 * separate options instead of one consolidated array.
	 */
	private function migrate_from_v2() {
		if ( get_option( 'emmytech_pro_migrated_v3' ) ) {
			return;
		}

		$legacy_logo   = get_option( 'emmytech_pro_logo_url', null );
		$legacy_accent = get_option( 'emmytech_pro_accent', null );
		$legacy_dark   = get_option( 'emmytech_pro_dark_mode', null );

		if ( null !== $legacy_logo || null !== $legacy_accent || null !== $legacy_dark ) {
			$current = get_option( EMMYTECH_PRO_OPTION, array() );
			$current = is_array( $current ) ? $current : array();

			if ( null !== $legacy_logo && '' === trim( (string) ( $current['logo_url'] ?? '' ) ) ) {
				$current['logo_url'] = $legacy_logo;
			}
			if ( null !== $legacy_accent ) {
				$current['accent_color'] = $legacy_accent;
			}
			if ( null !== $legacy_dark ) {
				$current['dark_admin_nav'] = $legacy_dark;
			}

			update_option( EMMYTECH_PRO_OPTION, array_merge( self::defaults(), $current ) );

			delete_option( 'emmytech_pro_logo_url' );
			delete_option( 'emmytech_pro_accent' );
			delete_option( 'emmytech_pro_dark_mode' );
		}

		update_option( 'emmytech_pro_migrated_v3', '1' );
	}

	/**
	 * 3.0 stored a single "show_dashboard_widget" flag covering one big
	 * widget. 3.1 splits the dashboard into four independent widgets, so
	 * that one flag is fanned out to the four new ones on upgrade.
	 */
	private function migrate_from_v30() {
		if ( get_option( 'emmytech_pro_migrated_v31' ) ) {
			return;
		}

		$current = get_option( EMMYTECH_PRO_OPTION, array() );
		$current = is_array( $current ) ? $current : array();

		if ( isset( $current['show_dashboard_widget'] ) && ! isset( $current['dashboard_widget_hero'] ) ) {
			$value                                    = $current['show_dashboard_widget'];
			$current['dashboard_widget_hero']          = $value;
			$current['dashboard_widget_stats']         = $value;
			$current['dashboard_widget_quick_actions'] = $value;
			$current['dashboard_widget_system_info']   = $value;
			unset( $current['show_dashboard_widget'] );

			update_option( EMMYTECH_PRO_OPTION, array_merge( self::defaults(), $current ) );
		}

		update_option( 'emmytech_pro_migrated_v31', '1' );
	}
}
