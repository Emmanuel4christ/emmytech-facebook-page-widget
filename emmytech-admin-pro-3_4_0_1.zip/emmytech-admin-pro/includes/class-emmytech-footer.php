<?php
/**
 * Admin footer module for EmmyTech Admin Pro.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EmmyTech_Footer {

	/** @var EmmyTech_Settings */
	private $settings;

	public function __construct( EmmyTech_Settings $settings ) {
		$this->settings = $settings;

		add_filter( 'admin_footer_text', array( $this, 'footer_text' ) );
		add_filter( 'update_footer', array( $this, 'footer_version' ), 11 );
	}

	public function footer_text( $text ) {
		$custom = $this->settings->get( 'custom_footer_text', '' );
		if ( '' === trim( wp_strip_all_tags( (string) $custom ) ) ) {
			return $text;
		}
		return wp_kses_post( $custom );
	}

	public function footer_version( $text ) {
		if ( '1' === $this->settings->get( 'hide_footer_version', '1' ) ) {
			return 'EmmyTech Admin Pro v' . esc_html( EMMYTECH_PRO_VERSION );
		}
		return $text;
	}
}
