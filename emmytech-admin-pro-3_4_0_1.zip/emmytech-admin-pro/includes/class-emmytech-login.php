<?php
/**
 * Login-screen module for EmmyTech Admin Pro.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class EmmyTech_Login {

	/** @var EmmyTech_Settings */
	private $settings;

	public function __construct( EmmyTech_Settings $settings ) {
		$this->settings = $settings;

		add_action( 'login_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'login_head', array( $this, 'head_overrides' ) );
		add_filter( 'login_headerurl', array( $this, 'header_url' ) );
		add_filter( 'login_headertext', array( $this, 'header_text' ) );
		add_filter( 'login_title', array( $this, 'title' ) );
		add_filter( 'login_body_class', array( $this, 'body_class' ) );
		add_filter( 'login_redirect', array( $this, 'maybe_redirect' ), 10, 3 );
	}

	public function enqueue_assets() {
		wp_enqueue_style( 'emmytech-pro-login', EMMYTECH_PRO_URL . 'assets/css/login.css', array(), EMMYTECH_PRO_VERSION );
	}

	/**
	 * Inline CSS for values that must come from settings (logo image,
	 * logo size, background/accent color). Kept minimal and escaped.
	 */
	public function head_overrides() {
		$logo   = $this->settings->get( 'logo_url' );
		$width  = absint( $this->settings->get( 'logo_width', 190 ) );
		$width  = $width > 0 ? $width : 190;
		$bg     = $this->settings->get( 'login_bg_color', '#0b0d10' );
		$accent = $this->settings->get( 'accent_color', '#5b8def' );

		echo "<style>\n";
		echo 'body.login.emmytech-pro-login{--emmy-login-bg:' . esc_attr( $bg ) . ';--emmy-accent:' . esc_attr( $accent ) . ";}\n";
		if ( $logo ) {
			echo 'body.login.emmytech-pro-login #login h1 a{background-image:url(' . esc_url( $logo ) . ');width:' . esc_attr( $width ) . "px;}\n";
		}
		echo "</style>\n";
	}

	public function header_url() {
		return home_url( '/' );
	}

	public function header_text() {
		return get_bloginfo( 'name' );
	}

	public function title( $title ) {
		return get_bloginfo( 'name' ) . ' — Secure Login';
	}

	public function body_class( $classes ) {
		$classes[] = 'emmytech-pro-login';
		return $classes;
	}

	/**
	 * Optional post-login redirect. Deliberately conservative:
	 * - Never overrides an explicit `redirect_to` the user already had
	 *   (e.g. from a "you must log in to see this page" bounce).
	 * - Leaves administrators alone by default, since most site owners
	 *   configuring this want to send *editors/subscribers* somewhere
	 *   other than wp-admin, not lock themselves out of it.
	 *
	 * @param string           $redirect_to
	 * @param string           $requested_redirect_to
	 * @param WP_User|WP_Error $user
	 * @return string
	 */
	public function maybe_redirect( $redirect_to, $requested_redirect_to, $user ) {
		$url = $this->settings->get( 'login_redirect_url', '' );

		if ( '' === trim( (string) $url ) ) {
			return $redirect_to;
		}
		if ( ! empty( $requested_redirect_to ) ) {
			return $redirect_to;
		}
		if ( is_wp_error( $user ) || ! ( $user instanceof WP_User ) ) {
			return $redirect_to;
		}
		if ( user_can( $user, 'manage_options' ) && '1' !== $this->settings->get( 'login_redirect_admins', '0' ) ) {
			return $redirect_to;
		}

		return esc_url_raw( $url );
	}
}
