/**
 * EmmyTech Admin Pro — Tools page.
 * Confirms the destructive "Reset to Defaults" action before it submits.
 */
( function ( $ ) {
	'use strict';

	$( function () {
		$( '#emmytech-reset-form' ).on( 'submit', function ( e ) {
			var message = ( window.EmmyTechTools && window.EmmyTechTools.confirmReset ) ||
				'This will restore every EmmyTech Admin Pro setting to its default value. Continue?';
			if ( ! window.confirm( message ) ) {
				e.preventDefault();
			}
		} );
	} );
} )( window.jQuery );
