/**
 * EmmyTech Admin Pro — live timers.
 * Two independent, dependency-free ticks:
 *  1. Activity Feed timestamps ("5 minutes ago") recompute every 30s so
 *     the feed keeps advancing without a page reload.
 *  2. The Server Information clock ticks every second from the timestamp
 *     the server rendered, entirely client-side (no repeated requests).
 * Both are no-ops if their markup isn't present, so this file is safe to
 * load on every wp-admin Dashboard view regardless of which widgets are
 * enabled.
 */
( function () {
	'use strict';

	/**
	 * Formats a whole number of seconds elapsed since `timestamp` (a Unix
	 * seconds value) into a short, human-friendly string. Mirrors the
	 * spirit of WordPress's own human_time_diff() closely enough for a
	 * live-updating display; the server-rendered text is authoritative on
	 * first paint and this only takes over after that.
	 *
	 * @param {number} timestamp Unix seconds.
	 * @return {string}
	 */
	function relativeTime( timestamp ) {
		var diff = Math.max( 0, Math.round( Date.now() / 1000 ) - timestamp );

		var units = [
			[ 31536000, 'year' ],
			[ 2592000, 'month' ],
			[ 604800, 'week' ],
			[ 86400, 'day' ],
			[ 3600, 'hour' ],
			[ 60, 'minute' ]
		];

		for ( var i = 0; i < units.length; i++ ) {
			var seconds = units[ i ][ 0 ];
			var label   = units[ i ][ 1 ];
			if ( diff >= seconds ) {
				var count = Math.floor( diff / seconds );
				return count + ' ' + label + ( count > 1 ? 's' : '' );
			}
		}
		return diff < 10 ? 'a few seconds' : diff + ' seconds';
	}

	function tickActivityTimes() {
		var nodes = document.querySelectorAll( '.emmytech-live-time[data-timestamp]' );
		nodes.forEach( function ( node ) {
			var ts = parseInt( node.getAttribute( 'data-timestamp' ), 10 );
			if ( ! ts ) {
				return;
			}
			var suffix = node.getAttribute( 'data-ago' ) || 'ago';
			node.textContent = relativeTime( ts ) + ' ' + suffix;
		} );
	}

	function tickServerClock() {
		var clock = document.getElementById( 'emmytech-clock-value' );
		var wrap  = document.getElementById( 'emmytech-server-clock' );
		if ( ! clock || ! wrap ) {
			return;
		}
		var baseTimestamp = parseInt( wrap.getAttribute( 'data-timestamp' ), 10 );
		if ( ! baseTimestamp ) {
			return;
		}
		if ( ! wrap.getAttribute( 'data-loaded-at' ) ) {
			wrap.setAttribute( 'data-loaded-at', String( Date.now() ) );
		}
		var loadedAt   = parseInt( wrap.getAttribute( 'data-loaded-at' ), 10 );
		var elapsed    = Math.floor( ( Date.now() - loadedAt ) / 1000 );
		var current    = new Date( ( baseTimestamp + elapsed ) * 1000 );

		function pad( n ) { return n < 10 ? '0' + n : String( n ); }

		clock.textContent = pad( current.getUTCHours() ) + ':' + pad( current.getUTCMinutes() ) + ':' + pad( current.getUTCSeconds() );
	}

	document.addEventListener( 'DOMContentLoaded', function () {
		tickActivityTimes();
		tickServerClock();
		setInterval( tickActivityTimes, 30000 );
		setInterval( tickServerClock, 1000 );
	} );
} )();
