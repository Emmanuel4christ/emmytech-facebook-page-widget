/**
 * EmmyTech Admin Pro — general admin script.
 * Kept intentionally tiny and dependency-free; only touches classes it owns.
 */
( function () {
	'use strict';

	document.addEventListener( 'DOMContentLoaded', function () {
		document.documentElement.classList.add( 'emmytech-pro-ready' );
	} );
} )();
