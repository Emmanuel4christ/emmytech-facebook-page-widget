/**
 * EmmyTech Admin Pro — Dashboard Settings page.
 * Powers the drag-to-reorder checklists used for both "Site Statistics"
 * and "Quick Actions". Only ever runs on our own Dashboard settings
 * screen (enqueued conditionally by EmmyTech_Assets::enqueue()), so
 * jQuery UI Sortable is guaranteed to be present.
 */
( function ( $ ) {
	'use strict';

	$( function () {
		$( '.emmytech-sortable-list' ).each( function () {
			var $list        = $( this );
			var $orderField  = $list
				.closest( '.emmytech-setting-card' )
				.find( 'input.emmytech-order-field' );

			function syncOrder() {
				var keys = $list.find( 'li' ).map( function () {
					return $( this ).data( 'key' );
				} ).get();
				$orderField.val( keys.join( ',' ) );
			}

			$list.sortable( {
				handle: '.emmytech-drag-handle',
				axis: 'y',
				update: syncOrder,
				cursor: 'move'
			} );

			// Keep the hidden order field correct even if nothing was
			// dragged, so a fresh page load still submits the displayed
			// order rather than an empty value.
			syncOrder();
		} );
	} );
} )( window.jQuery );
