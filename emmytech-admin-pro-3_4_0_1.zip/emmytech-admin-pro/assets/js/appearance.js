/**
 * EmmyTech Admin Pro — Appearance page live preview.
 * Only ever runs on our own settings screen (enqueued conditionally by
 * enqueue_admin_assets()), so it is safe to assume jQuery + wp-color-picker
 * are both available here.
 */
( function ( $ ) {
	'use strict';

	$( function () {
		var $preview      = $( '#emmytech-live-preview' );
		var $darkToggle   = $( '#dark_admin_nav_live' );
		var $accentField  = $( '#accent_color_live' );

		if ( ! $preview.length ) {
			return;
		}

		function applyDarkState() {
			$preview
				.toggleClass( 'is-dark', $darkToggle.is( ':checked' ) )
				.toggleClass( 'is-light', ! $darkToggle.is( ':checked' ) );
		}

		function applyAccent( color ) {
			if ( ! color ) {
				return;
			}
			$preview.css( '--preview-accent', color );
		}

		$darkToggle.on( 'change', applyDarkState );

		if ( $.fn.wpColorPicker ) {
			$accentField.wpColorPicker( {
				change: function ( event, ui ) {
					applyAccent( ui.color.toString() );
				},
				clear: function () {
					applyAccent( '#5b8def' );
				}
			} );
		} else {
			$accentField.on( 'input change', function () {
				applyAccent( $( this ).val() );
			} );
		}

		applyDarkState();
		applyAccent( $accentField.val() );
	} );
} )( window.jQuery );
