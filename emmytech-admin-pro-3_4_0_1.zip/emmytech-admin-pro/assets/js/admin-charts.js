/**
 * EmmyTech Admin Pro — dashboard chart renderer.
 * Reads the JSON payload each chart widget embeds next to its <canvas>
 * (see EmmyTech_Dashboard::render_chart_canvas()) and draws it with the
 * bundled Chart.js. Keeping this in one file means every chart gets
 * identical theming, and PHP never has to touch the Chart.js API.
 */
( function () {
	'use strict';

	if ( typeof window.Chart === 'undefined' ) {
		return;
	}

	var accent = getComputedStyle( document.documentElement ).getPropertyValue( '--emmy-accent' ).trim() || '#5b8def';

	/**
	 * Reads the background of the widget a canvas sits in, so axis, grid and
	 * label colors stay readable whether the card is light or dark.
	 */
	function cardIsDark( el ) {
		var card = el.closest ? el.closest( '.postbox' ) : null;
		var bg   = card ? window.getComputedStyle( card ).backgroundColor : '';
		var m    = bg.match( /rgba?\(\s*(\d+),\s*(\d+),\s*(\d+)/ );
		if ( ! m ) {
			return false;
		}
		return ( 0.299 * m[ 1 ] + 0.587 * m[ 2 ] + 0.114 * m[ 3 ] ) < 128;
	}

	/** '#5b8def' -> 'rgba(91,141,239,0.15)' (used for the line-chart fill). */
	function withAlpha( hex, alpha ) {
		var m = /^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec( hex );
		if ( ! m ) {
			return 'rgba(91,141,239,' + alpha + ')';
		}
		return 'rgba(' + parseInt( m[ 1 ], 16 ) + ',' + parseInt( m[ 2 ], 16 ) + ',' + parseInt( m[ 3 ], 16 ) + ',' + alpha + ')';
	}

	// Small plugin: draws a centered percentage/label inside a doughnut
	// chart's hole. Its options are an OBJECT ({ text, color }) — Chart.js
	// resolves every plugin's options into a proxy object, so a bare string
	// here would arrive as an object and make fillText() throw.
	var centerTextPlugin = {
		id: 'emmytechCenterText',
		afterDraw: function ( chart ) {
			var opts = chart.options.plugins && chart.options.plugins.emmytechCenterText;
			var text = opts && opts.text ? String( opts.text ) : '';
			if ( ! text ) {
				return;
			}
			var ctx = chart.ctx;
			var x   = chart.chartArea.left + ( chart.chartArea.right - chart.chartArea.left ) / 2;
			var y   = chart.chartArea.top + ( chart.chartArea.bottom - chart.chartArea.top ) / 2;
			ctx.save();
			ctx.font         = '700 22px -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';
			ctx.fillStyle    = opts.color || '#171a1e';
			ctx.textAlign    = 'center';
			ctx.textBaseline = 'middle';
			ctx.fillText( text, x, y );
			ctx.restore();
		}
	};
	window.Chart.register( centerTextPlugin );

	function buildConfig( payload, dark ) {
		var palette   = [ accent, '#17c3b2', '#9b59b6', '#f5a623', '#2ecc71', '#e84393' ];
		var textColor = dark ? '#aeb4ba' : '#6b737b';
		var gridColor = dark ? 'rgba(255,255,255,.06)' : 'rgba(15,20,25,.07)';

		var datasets = payload.datasets.map( function ( ds, i ) {
			if ( 'doughnut' === payload.type ) {
				return {
					data: ds.data,
					backgroundColor: ds.colors || palette,
					borderWidth: 0,
					hoverOffset: 4
				};
			}
			if ( 'line' === payload.type ) {
				return {
					label: ds.label || '',
					data: ds.data,
					borderColor: accent,
					backgroundColor: withAlpha( accent, 0.15 ),
					fill: true,
					tension: 0.4,
					pointRadius: 0,
					pointHoverRadius: 4,
					borderWidth: 2
				};
			}
			// bar
			return {
				label: ds.label || '',
				data: ds.data,
				backgroundColor: palette[ i % palette.length ],
				borderRadius: 6,
				maxBarThickness: 28
			};
		} );

		var options = {
			responsive: true,
			maintainAspectRatio: false,
			plugins: {
				legend: { display: datasets.length > 1, labels: { color: textColor } },
				tooltip: { enabled: true }
			}
		};

		if ( 'doughnut' === payload.type ) {
			options.cutout = '72%';
			options.plugins.legend.display = false;
			options.plugins.emmytechCenterText = {
				text: payload.centerText || '',
				color: dark ? '#ffffff' : '#171a1e'
			};
		} else {
			options.scales = {
				x: { grid: { display: false }, ticks: { color: textColor } },
				y: { grid: { color: gridColor }, ticks: { color: textColor, precision: 0 }, beginAtZero: true }
			};
		}

		return {
			type: payload.type,
			data: { labels: payload.labels, datasets: datasets },
			options: options
		};
	}

	document.addEventListener( 'DOMContentLoaded', function () {
		var nodes = document.querySelectorAll( '.emmytech-chart-data' );
		nodes.forEach( function ( node ) {
			// One misbehaving chart must never stop the others from drawing.
			try {
				var canvas = document.getElementById( node.getAttribute( 'data-target' ) );
				if ( ! canvas ) {
					return;
				}
				var payload = JSON.parse( node.textContent );
				new window.Chart( canvas, buildConfig( payload, cardIsDark( canvas ) ) );
			} catch ( e ) {
				if ( window.console && window.console.error ) {
					window.console.error( 'EmmyTech Admin Pro: a chart could not be drawn.', e );
				}
			}
		} );
	} );
} )();
