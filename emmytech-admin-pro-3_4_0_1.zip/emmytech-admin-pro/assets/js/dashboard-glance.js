/**
 * EmmyTech Admin Pro — "At a glance" dashboard layout.
 *
 * In this layout every widget has a fixed place (set in CSS), so WordPress's
 * drag-to-reorder is switched off; otherwise a dragged widget would appear
 * to snap straight back while still saving a pointless order for the user.
 * Collapse and Screen Options show/hide keep working as normal.
 *
 * Only enqueued on the Dashboard when the "At a glance" layout is active
 * (see EmmyTech_Assets::enqueue()).
 */
( function ( $ ) {
	'use strict';

	if ( ! $ ) {
		return;
	}

	// WordPress attaches its sortables during its own DOM-ready handler, so
	// wait for the window `load` event: by then they are guaranteed to exist.
	$( window ).on( 'load', function () {
		$( '#dashboard-widgets .meta-box-sortables' ).each( function () {
			try {
				$( this ).sortable( 'disable' );
			} catch ( e ) {
				// Not initialised (e.g. on a touch device): nothing to disable.
			}
		} );
	} );
} )( window.jQuery );
