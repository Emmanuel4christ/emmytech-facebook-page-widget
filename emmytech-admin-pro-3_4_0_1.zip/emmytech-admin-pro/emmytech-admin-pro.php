<?php
/**
 * Plugin Name: EmmyTech Admin Pro
 * Plugin URI:  https://www.emmytech.online/
 * Description: Full EmmyTech-branded WordPress admin and login interface customization system — branded login, dark admin navigation, a full-width, at-a-glance Control Center dashboard with live charts, a live activity feed, live site/server information, live site statistics, quick actions, and admin-menu decluttering.
 * Version:     3.4.0
 * Author:      EmmyTech Software Solution
 * Author URI:  https://www.emmytech.online/
 * License:     GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: emmytech-admin-pro
 * Requires PHP: 7.2
 * Requires at least: 5.5
 */

// Block direct file access — this file must only ever run inside WordPress.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// --------------------------------------------------------------------
// Core constants. Everything is namespaced behind EMMYTECH_PRO_ to stay
// clear of core, theme, and other-plugin option/hook names.
// --------------------------------------------------------------------
define( 'EMMYTECH_PRO_VERSION', '3.4.0' );
define( 'EMMYTECH_PRO_OPTION', 'emmytech_pro_settings' );
define( 'EMMYTECH_PRO_FILE', __FILE__ );
define( 'EMMYTECH_PRO_URL', plugin_dir_url( __FILE__ ) );
define( 'EMMYTECH_PRO_PATH', plugin_dir_path( __FILE__ ) );
define( 'EMMYTECH_PRO_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Load the plugin's class file and boot it.
 *
 * Everything else lives inside the EmmyTech_Admin_Pro class so the plugin
 * never leaks functions or globals into the global namespace beyond this
 * one loader — a core-safe pattern that avoids collisions with themes,
 * other plugins, and WordPress core itself.
 */
require_once EMMYTECH_PRO_PATH . 'includes/class-emmytech-admin-pro.php';

/**
 * Returns the single running instance of the plugin.
 *
 * @return EmmyTech_Admin_Pro
 */
function emmytech_admin_pro() {
	return EmmyTech_Admin_Pro::instance();
}
emmytech_admin_pro();

/**
 * One-time activation tasks. We only ever write our own prefixed option —
 * never touch core options, tables, or other plugins' data.
 */
function emmytech_pro_activate() {
	if ( false === get_option( EMMYTECH_PRO_OPTION ) ) {
		add_option( EMMYTECH_PRO_OPTION, EmmyTech_Admin_Pro::default_settings() );
	}
	// Remember the version that last ran so future upgrades can migrate safely.
	update_option( 'emmytech_pro_version', EMMYTECH_PRO_VERSION );
}
register_activation_hook( __FILE__, 'emmytech_pro_activate' );
