<?php
/**
 * Uninstall handler for EmmyTech Admin Pro.
 *
 * WordPress only executes this file when the plugin is deleted from the
 * Plugins screen (or via WP-CLI `plugin delete`) — never on deactivation —
 * and only when it is loaded directly by core with WP_UNINSTALL_PLUGIN
 * defined. That guard below is required by the WordPress Plugin Handbook
 * and stops this file from doing anything if it's ever accessed on its own.
 *
 * This is the recommended core-safe cleanup pattern (rather than
 * register_uninstall_hook in the main file) because it never has to load
 * the rest of the plugin just to remove its data.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Deletes every option EmmyTech Admin Pro has ever written, including
 * legacy pre-3.0 option names, for a single site.
 */
function emmytech_pro_delete_site_options() {
	delete_option( 'emmytech_pro_settings' );
	delete_option( 'emmytech_pro_version' );
	delete_option( 'emmytech_pro_migrated_v3' );
	delete_option( 'emmytech_pro_migrated_v31' );

	// Cached dashboard chart/activity data.
	delete_transient( 'emmytech_pro_weekly_activity' );
	delete_transient( 'emmytech_pro_content_growth' );
	delete_transient( 'emmytech_pro_activity_feed' );

	// Legacy (pre-3.0) individual options, kept here in case a site is
	// deleting an old version directly without ever having activated 3.0.
	delete_option( 'emmytech_pro_logo_url' );
	delete_option( 'emmytech_pro_accent' );
	delete_option( 'emmytech_pro_dark_mode' );
}

/**
 * Removes the last-login timestamp the Activity Feed widget records on
 * every user (see EmmyTech_Dashboard::record_login()). Meta, not an
 * option, so it needs its own cleanup call: delete_metadata() with
 * $delete_all = true removes it for every user network-wide in one call,
 * rather than looping every site and every user.
 */
function emmytech_pro_delete_user_meta() {
	delete_metadata( 'user', 0, '_emmytech_pro_last_login', '', true );
}

if ( is_multisite() ) {
	// Clean up on every site in the network, not just the one where the
	// plugin happened to be network-deleted from.
	$site_ids = get_sites( array( 'fields' => 'ids' ) );
	foreach ( $site_ids as $site_id ) {
		switch_to_blog( $site_id );
		emmytech_pro_delete_site_options();
		restore_current_blog();
	}
} else {
	emmytech_pro_delete_site_options();
}

// User meta is shared network-wide (it isn't per-site), so this runs once
// regardless of single-site or multisite.
emmytech_pro_delete_user_meta();
